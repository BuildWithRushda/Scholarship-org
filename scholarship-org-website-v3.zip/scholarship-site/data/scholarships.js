/* Generated from the Scholarship.org Research Tracker. Edit records here, keeping verification fields exact. */
window.SCHOLARSHIP_DATA = {
 "asOf": "2026-10-28",
 "source": "Scholarship.org Research Tracker (27 Oct 2026 version)",
 "records": [
  {
   "id": "SCH-001",
   "name": "AICTE Pragati Scholarship Scheme for Girl Students (Technical Degree and Technical Diploma)",
   "country": "India",
   "provider": "All India Council for Technical Education (AICTE), Ministry of Education, Govt. of India",
   "studyLevel": "Undergraduate (technical degree) and Diploma. Applies to study in India only.",
   "levels": [
    "undergraduate-applicant",
    "professional"
   ],
   "subjects": [
    "Engineering"
   ],
   "types": [
    "government",
    "partial",
    "need",
    "tuition"
   ],
   "indian": "Yes",
   "nationalities": "Indian citizens (Indian girl students). Confirm exact clause on the official guidelines.",
   "categories": "Girl students admitted to the 1st year of an AICTE-approved technical degree or diploma course (2nd year for lateral-entry diploma). Maximum two girl children per family.",
   "academic": "Admission to an AICTE-approved institution. Detailed merit criteria: Not confirmed.",
   "income": "Annual family income below Rs 8,00,000 (per June 2026 scheme update). Confirm on official guidelines.",
   "courses": "AICTE-approved technical degree and diploma courses only.",
   "funding": "Partial. Fixed annual award towards fees, books, equipment and software. Not full funding.",
   "amount": "Rs 50,000 per year, paid by DBT. About 5,000 degree and 5,000 diploma awards per year (third-party summaries).",
   "openingISO": "2026-06-01",
   "openingNote": null,
   "deadlineISO": "2026-10-31",
   "deadlineNote": null,
   "admission": "Yes. Must be admitted to an AICTE-approved institution.",
   "nomination": "No. Institute-level verification only.",
   "documents": "NSP One Time Registration (OTR) required before applying. Full document list: Not confirmed.",
   "officialLink": "https://www.aicte.gov.in/schemes/students-development-schemes/Pragati/General-Instructions",
   "applicationLink": "https://www.nsp.gov.in",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Deadline confirmed by AICTE notice dated 19.06.2026 (copy hosted by Thapar Institute). Closes 31 Oct 2026, four days after this check. Girl students only. Verification deadlines: institute 15 Nov 2026; state nodal officer 30 Nov 2026. Amount and income limit come from third-party summaries; check the official guidelines before marking Verified.",
   "watchlist": false
  },
  {
   "id": "SCH-002",
   "name": "PM YASASVI Central Sector Scheme of Top Class Education in College for OBC, EBC and DNT Students",
   "country": "India",
   "provider": "Ministry of Social Justice and Empowerment, Govt. of India (via National Scholarship Portal)",
   "studyLevel": "Undergraduate: full-time prescribed course after Class 12 at a notified institution",
   "levels": [
    "undergraduate-applicant",
    "current-undergraduate"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "government",
    "partial",
    "need",
    "tuition",
    "living"
   ],
   "indian": "Yes",
   "nationalities": "Indian nationals only.",
   "categories": "OBC, EBC or DNT students only. 30% of slots reserved for girls (Ministry scheme note). Merit-based if applicants exceed slots.",
   "academic": "Admission to a full-time prescribed course at a notified institution. Selection by inter-se merit per admission criteria.",
   "income": "Family income up to Rs 2,50,000 per year from all sources.",
   "courses": "Full-time prescribed courses at notified institutions (IITs, IIMs, NITs, AIIMS, NLUs, NIFTs, NIDs and others). Full list: Not confirmed.",
   "funding": "Partial at private institutions (tuition capped at Rs 2 lakh a year), plus living, books and laptop allowances. Fees above the cap are not covered.",
   "amount": "Tuition up to Rs 2,00,000 per year at private notified institutions (full tuition at government notified institutions). Rs 3,000 per month living. Rs 5,000 per year books and stationery. One-time laptop assistance up to Rs 45,000.",
   "openingISO": "2026-06-01",
   "openingNote": null,
   "deadlineISO": "2026-10-31",
   "deadlineNote": null,
   "admission": "Yes. Admission to a notified institution is part of eligibility. Confirm whether an offer letter is needed before applying.",
   "nomination": "No.",
   "documents": "OTR on NSP; caste certificate (OBC/EBC/DNT); income certificate; academic marksheets; bank details; admission proof. Full list: Not confirmed.",
   "officialLink": "https://ccras.nic.in/wp-content/uploads/2026/06/01062026-PM-YASASVI-Scheme.pdf",
   "applicationLink": "https://scholarships.gov.in",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Confirmed from the Ministry scheme document (June 2026 copy on ccras.nic.in): income up to Rs 2.5 lakh; 30% of slots for girls; no more than two siblings per family (affidavit required). Correction: the Rs 3.72 lakh ceiling applies only to private flying clubs for pilot training, not general tuition. Correction: the 20 Oct 2026 deadline in an earlier note has no supporting source. Deadlines 31 Oct 2026 (student), 15 Nov (defective and institute verification), 30 Nov (DNO/SNO verification) are confirmed by several sources, but the live NSP date should be checked before applying. Only for OBC/EBC/DNT students admitted to notified institutions; not for study abroad.",
   "watchlist": false
  },
  {
   "id": "SCH-003",
   "name": "Mitsui & Co. Scholarship Program for India (2027 intake)",
   "country": "Japan",
   "provider": "Mitsui & Co., Ltd., Tokyo (program established 2024)",
   "studyLevel": "Undergraduate (bachelor's degree at a Japanese university), preceded by 1.5 years of Japanese language study. Total 5.5 years.",
   "levels": [
    "class-12",
    "undergraduate-applicant"
   ],
   "subjects": [
    "Science & Mathematics",
    "Engineering",
    "Business & Economics"
   ],
   "types": [
    "private",
    "full",
    "living",
    "tuition",
    "merit"
   ],
   "indian": "Yes",
   "nationalities": "Citizens of the Republic of India only.",
   "categories": "Unmarried; not more than 20 years of age as of 1 April 2027; must not hold another scholarship or financial assistance at time of application (2027 prospectus, clauses 2(b) and 2(g)).",
   "academic": "Minimum 85% aggregate in both Class 10 and Class 12 (or Class 10 and Class 11 for students finishing Class 12 by March 2027, with Class 12 mid-term results at interview). JLPT N3 or higher, or a strong EJU score, is an advantage. Selection: online test (English, two sciences, mathematics, aptitude), then final interview.",
   "income": "Not stated in the 2027 prospectus (no income criterion found).",
   "courses": "Sciences and engineering (e.g. Mathematics, Physics, Chemistry, Information and Computer Science, Electrical and Electronics, Information and Communication Engineering) and social sciences, business and commerce (e.g. Economics, Accounting, Finance). Excluded: medical, pharmaceutical and veterinary science, arts, physical education, nursing and similar specialised fields. Field of study cannot be changed after entry.",
   "funding": "Full funding: entrance exam fees and tuition at the Japanese language school and university, plus living allowance, lodging subsidy, insurance and textbooks.",
   "amount": "JPY 145,000 per month living allowance; JPY 50,000 arrival allowance; lodging subsidy JPY 5,000 per month at language school or JPY 25,000 per month at university; one-way economy airfare to Japan (return flight on conditions).",
   "openingISO": "2026-10-09",
   "openingNote": null,
   "deadlineISO": "2026-11-08",
   "deadlineNote": null,
   "admission": "No. Applicants apply to the Program; the 2027 prospectus does not require a university admission first.",
   "nomination": "No.",
   "documents": "Passport photo; Aadhaar or passport copy; Class 10 and Class 12 marksheets (or Class 10 and 11 if still in Class 12); physical fitness certificate; declaration and parental authorisation forms; English certificate if English was not studied at school; any awards; EJU and JLPT results if held; typed report on intended field of study and career plan.",
   "officialLink": "https://www.studyinjapan.go.jp/en/_mt/2026/10/2610161600_01_en.pdf",
   "applicationLink": "https://mitsui.acumen.education",
   "lastVerified": "2026-10-27",
   "verification": "Verified",
   "notes": "Verified against the official 2027 prospectus (studyinjapan.go.jp, Government of Japan site). Application deadline 8 Nov 2026. Opening date 9 Oct 2026 per official Study in Japan notice. Corrections made: age limit is 20 as of 1 April 2027 (not 2026); the Science or Commerce stream requirement was removed (not in the prospectus); fields of study confirmed; airfare, insurance and textbooks confirmed; application link changed from LinkedIn to the official portal. Undergraduate study in Japan, not India.",
   "watchlist": false
  },
  {
   "id": "SCH-004",
   "name": "UBC International Scholars Program (2027 entry): Karen McKellin International Leader of Tomorrow Award; Donald A. Wehrung International Student Award; International Impact Award; Vantage One Excellence Award",
   "country": "Canada",
   "provider": "University of British Columbia (UBC), Vancouver and Okanagan campuses",
   "studyLevel": "Undergraduate (first-year entry, September 2027)",
   "levels": [
    "class-12",
    "undergraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "need",
    "partial",
    "full"
   ],
   "indian": "Conditional",
   "nationalities": "International students (no nationality restriction stated). Indian students are not excluded.",
   "categories": "International students entering UBC directly from secondary school. Must hold or be eligible for a Canadian study permit. Must be nominated by school guidance counsellor/administrator or an eligible non-profit (non-profits nominate high-school students only).",
   "academic": "Superior academic achievement (third-party guides: all As or equivalent). English language admission standard, or Vantage One route if not met.",
   "income": "Significant demonstrated financial need required. Family income, expense and asset documents needed. No fixed income cap published.",
   "courses": "Undergraduate programmes at UBC Vancouver or UBC Okanagan (first-choice programme used for award consideration).",
   "funding": "Partial to full, need-based. Full coverage only where assessed need is met; not guaranteed.",
   "amount": "No fixed value published for three of the four awards; each is sized to demonstrated financial need. Vantage One Excellence Award: up to the full cost of the academic programme and living expenses.",
   "openingISO": "2026-10-05",
   "openingNote": null,
   "deadlineISO": "2026-11-15",
   "deadlineNote": null,
   "admission": "Yes. Must submit a UBC undergraduate admission application (third-party guides: complete UBC admission first).",
   "nomination": "Yes. School or eligible non-profit nomination required. Teacher referee also required.",
   "documents": "UBC admission application; school nominator form (counsellor or administrator); teacher referee (different person from nominator); financial disclosure (income, expenses, assets); four essays of about 150-250 words each; high school transcripts; English test scores. Supporting documents due 31 Jan 2027; possible video interview Jan-Mar 2027.",
   "officialLink": "https://you.ubc.ca/financial-planning/scholarships-awards-international-students/international-scholars/",
   "applicationLink": "Not confirmed. Start from UBC Undergraduate Admissions and the International Scholars page above.",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "UBC programme page and quoted timetable: applications open early Oct 2026 (5 Oct per guide); award application closes 15 Nov 2026, 11:59 pm PST; supporting documents due 31 Jan 2027; results Feb-Apr 2027. The 1 Dec 2026 date in one listing is not supported and has been removed. Official UBC page confirms the four awards, school nomination and need-and-merit basis. Vantage One: up to full cost. Other awards: no fixed amount. Not guaranteed. Verify on you.ubc.ca once the 2027 application page is live.",
   "watchlist": false
  },
  {
   "id": "SCH-005",
   "name": "University of Exeter Undergraduate Scholarship 2027/28 for India",
   "country": "United Kingdom",
   "provider": "University of Exeter",
   "studyLevel": "Undergraduate (first-year direct entry, September 2027)",
   "levels": [
    "undergraduate-applicant"
   ],
   "subjects": [
    "Computer Science & IT",
    "Engineering",
    "Science & Mathematics",
    "Business & Economics"
   ],
   "types": [
    "university",
    "partial",
    "tuition"
   ],
   "indian": "Conditional",
   "nationalities": "Citizens and passport holders of India, classed as international fee students.",
   "categories": "Self-funded Indian students who hold an offer for an eligible campus-based undergraduate programme. Students progressing from the Exeter International Study Centre Foundation are not eligible.",
   "academic": "Offer-based; academic requirements set by the offer. Not confirmed in the T&Cs.",
   "income": "Not applicable. No income test stated. Scholarship is intended for self-funded students.",
   "courses": "Eligible departments include Computer Science, Engineering, Mathematics and Statistics, Economics, Finance and Accounting, Geography, Earth and Environmental Science, Ecology and Conservation (plus others listed in T&Cs). Excluded: BMBS Medicine; BSc Medical Imaging; Dual LLB/JD; Brickfields Asia College LLB; SFU double-degree; Degree Apprenticeships.",
   "funding": "Partial. Tuition fee reduction only.",
   "amount": "GBP 3,000 per eligible year (recurring tuition fee discount for each year the full fee is due). Not for study abroad, placement or repeat years.",
   "openingISO": null,
   "openingNote": "Not confirmed",
   "deadlineISO": "2027-06-30",
   "deadlineNote": null,
   "admission": "Yes. Must hold an offer to study an eligible undergraduate programme at Exeter.",
   "nomination": "No.",
   "documents": "Not confirmed. Standard Exeter offer and admission documents apply.",
   "officialLink": "https://www.exeter.ac.uk/study/funding/award/?id=5917",
   "applicationLink": "https://www.exeter.ac.uk/study/undergraduate/",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Official 2027/28 T&Cs (version 1.1, 23 Sep 2026) confirm: GBP 3,000 recurring tuition reduction; India included; offer required; awards allocated automatically with no separate application; eligible programmes applied for by 30 June 2027; Computer Science is an eligible department; BMBS Medicine and several other programmes are excluded. Correction: the earlier note that Exeter Excellence Scholarships can be combined is not supported; the T&Cs say only one tuition discount is normally allowed. Opening date not stated (Not confirmed).",
   "watchlist": false
  },
  {
   "id": "SCH-006",
   "name": "UNSW International Scientia Coursework Scholarship (PUCA1025), applied for via PUCA1029 (Term 1 2027)",
   "country": "Australia",
   "provider": "University of New South Wales (UNSW Sydney)",
   "studyLevel": "Undergraduate and postgraduate coursework (full-time, on campus)",
   "levels": [
    "undergraduate-applicant",
    "postgraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "merit",
    "partial",
    "full",
    "tuition"
   ],
   "indian": "Conditional",
   "nationalities": "International students. No nationality restriction stated on official page.",
   "categories": "International students commencing full-time UNSW coursework in Term 1 2027 with an eligible UNSW offer by 30 Oct 2026. Selection on academic merit, leadership, extracurricular activities and reasons for studying at UNSW.",
   "academic": "Academic merit assessed. Minimum grades: Not confirmed. CBSE Class 12 eligibility: Not confirmed (depends on UNSW admission requirements; not stated on scholarship page).",
   "income": "No income limit stated (merit-based award).",
   "courses": "Any full-time UNSW undergraduate or postgraduate coursework degree, excluding UNSW Online and UNSW Canberra. Computer Science not named specifically: Not confirmed.",
   "funding": "Partial or full, tuition only. Offer 1: full tuition for minimum programme duration. Offer 2: towards tuition for minimum programme duration.",
   "amount": "Offer 1: full tuition fee scholarship. Offer 2: AUD 20,000 per year towards tuition fees. Offer type allocated by UNSW.",
   "openingISO": "2026-07-06",
   "openingNote": null,
   "deadlineISO": "2026-10-30",
   "deadlineNote": null,
   "admission": "Yes. Must hold an eligible UNSW offer for Term 1 2027 by 30 Oct 2026 (unconditional, or conditional without GS or English conditions; UEEC offers accepted).",
   "nomination": "No. Separate scholarship application required through UNSW portal.",
   "documents": "Online scholarship application; personal statement; evidence of leadership, extracurricular and community or work experience (see official Supporting Documentation Guide); English test scores if required for admission.",
   "officialLink": "https://www.scholarships.unsw.edu.au/scholarships/id/1988",
   "applicationLink": "https://scholarships.online.unsw.edu.au/scholarship/sc_search.login",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "URGENT: closes 30 Oct 2026, 11:59 pm AEST (about 3 days from this check). Open status confirmed on official PUCA1029 page. Opening date: page body says 6 July 2026, but the sidebar on the same page says 15/07/2026, so 6 July is used. CBSE and Computer Science eligibility not explicitly confirmed; check before marking Verified. Tuition only, not living costs. Not the same as the separate International Student Award on the same page.",
   "watchlist": false
  },
  {
   "id": "SCH-007",
   "name": "Cardiff University Undergraduate International Excellence Scholarship (2027 entry)",
   "country": "United Kingdom",
   "provider": "Cardiff University",
   "studyLevel": "Undergraduate, full-time, Cardiff campus-based taught programmes (excludes Dentistry, Medicine and Healthcare schools)",
   "levels": [
    "undergraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "merit",
    "partial",
    "tuition"
   ],
   "indian": "Conditional",
   "nationalities": "Overseas (international) fee-paying students. Nationality not restricted; eligibility depends on being classed as an overseas fee payer.",
   "categories": "Overseas fee status; self-financed (no non-repayable external funding); holding an offer for an eligible undergraduate degree starting September 2027 when submitting the scholarship application.",
   "academic": "Assessed on quality of scholarship application and academic application, predicted and final grades. Must meet published minimum entry requirements exactly. CBSE Class 12 eligibility: Not confirmed.",
   "income": "No income limit stated; must be self-financed.",
   "courses": "Full-time, Cardiff campus-based taught undergraduate programmes (excludes Dentistry, Medicine and Healthcare). Computer Science eligibility: Not confirmed (check course list).",
   "funding": "Partial. Tuition fee discount only; first year only; no cash alternative; cannot replace a deposit.",
   "amount": "GBP 10,000 one-off tuition fee discount (first year only).",
   "openingISO": null,
   "openingNote": "Not confirmed",
   "deadlineISO": "2027-04-02",
   "deadlineNote": null,
   "admission": "Yes. Must hold an offer for an eligible programme when submitting the scholarship application.",
   "nomination": "No. Separate scholarship application required (2027 invitation and form details: Not confirmed).",
   "documents": "Scholarship application (2026 form had a 300-word achievement question; 2027 form Not confirmed); academic application; predicted and final grades.",
   "officialLink": "https://www.cardiff.ac.uk/documents/3072699-undergraduate-international-excellence-scholarships-2027-terms-and-eligibility-criteria",
   "applicationLink": "Not confirmed",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Deadline confirmed from Cardiff's official 2027 terms (last updated 26 Aug 2026): 23:59 UK time, Friday 2 April 2027. Opening date not confirmed. The official document is internally inconsistent: clause 3 says 2026/27 entry only, while clause 3.1 refers to 2027/28 entry. Treat as 2027 entry until confirmed with InternationalScholarships@cardiff.ac.uk. Cannot be combined with other scholarships (clause 5), so not stackable with SCH-008.",
   "watchlist": false
  },
  {
   "id": "SCH-008",
   "name": "Cardiff University Vice-Chancellor's Undergraduate International Scholarship (September 2027 entry)",
   "country": "United Kingdom",
   "provider": "Cardiff University",
   "studyLevel": "Undergraduate, full-time, selected Cardiff campus-based taught programmes (excludes Dentistry, Medicine and Healthcare; certificate and diploma awards excluded)",
   "levels": [
    "undergraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "merit",
    "partial",
    "tuition"
   ],
   "indian": "Conditional",
   "nationalities": "Overseas fee-paying students. GBP 5,000 for students domiciled in India, Kenya, Pakistan, Turkey, UAE or USA; GBP 3,500 for other eligible overseas students.",
   "categories": "Overseas fee status; self-financed; full-time, Cardiff campus-based taught programme; year 1 entry in autumn 2027/28.",
   "academic": "Must meet the published minimum academic entry requirements exactly at time of application; offers with lower grades are ineligible. CBSE Class 12 eligibility: Not confirmed.",
   "income": "No income limit stated; must be self-financed.",
   "courses": "Selected undergraduate degree programmes (official list Not confirmed). Computer Science eligibility: Not confirmed.",
   "funding": "Partial. Tuition fee discount only; first year only; no cash alternative.",
   "amount": "GBP 5,000 tuition fee discount if India-domiciled (domicile declared in course application); GBP 3,500 otherwise.",
   "openingISO": null,
   "openingNote": "Not confirmed",
   "deadlineISO": "2027-06-30",
   "deadlineNote": null,
   "admission": "Yes. Must submit the university application and hold an eligible offer (conditional or unconditional).",
   "nomination": "No. Awarded automatically on enrolment; no separate scholarship application.",
   "documents": "University application to Cardiff; domicile declared in course application. Full document list: Not confirmed.",
   "officialLink": "https://www.cardiff.ac.uk/documents/3072502-vice-chancellors-undergraduate-international-scholarship-terms-and-conditions-september-2027-entry",
   "applicationLink": "Not applicable (no separate scholarship application). University application link: Not confirmed.",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Official September 2027 terms (last updated 25 Aug 2026): university application due 30 June 2027 for conditional and unconditional offer holders; award automatic. India domicile means ordinarily resident for 3+ years before course start, not nationality alone. Cannot be combined with SCH-007. Scholarship-eligibility queries accepted until 30 Nov 2027.",
   "watchlist": false
  },
  {
   "id": "SCH-009",
   "name": "University of St Andrews International Undergraduate Scholarship (entry 2027)",
   "country": "United Kingdom",
   "provider": "University of St Andrews (Scotland)",
   "studyLevel": "Undergraduate, first-year entry (includes direct entry to year 2; not transfers)",
   "levels": [
    "undergraduate-applicant"
   ],
   "subjects": [
    "Computer Science & IT",
    "Science & Mathematics",
    "Business & Economics"
   ],
   "types": [
    "university",
    "need",
    "partial",
    "tuition"
   ],
   "indian": "Conditional",
   "nationalities": "Overseas fee-status students. No nationality restriction stated; Indian applicants qualify if classed as overseas for fee purposes.",
   "categories": "Overseas fee status; first-year undergraduate entry in 2027; means-tested financial need. Priority circumstances listed: financial need, previous needs-based funding, socio-economically disadvantaged neighbourhood, disability, minority group.",
   "academic": "Not confirmed (course entry requirements apply). CBSE Class 12 eligibility: Not confirmed.",
   "income": "Means-tested. Household gross annual income (GBP) entered in application. Income threshold: Not confirmed.",
   "courses": "Eligible Schools include Computer Science, Mathematics and Statistics, Physics and Astronomy, Business School and others. Excludes BA International Honours joint courses with William & Mary.",
   "funding": "Partial. Tuition fee reduction for each year of undergraduate study, need-based.",
   "amount": "Value to be confirmed by December 2026 (per official page).",
   "openingISO": "2026-08-17",
   "openingNote": null,
   "deadlineISO": "2027-01-27",
   "deadlineNote": null,
   "admission": "No. You can apply once your course application is submitted; an offer is not required first. Allow two working days for login details after course application.",
   "nomination": "Yes. Separate scholarship application through the University of St Andrews International Undergraduate Scholarships form (My Application portal).",
   "documents": "Scholarship application form; household income in GBP (financial funding tool); evidence of financial need or circumstances. Full list: Not confirmed. Form guidance PDF on official site.",
   "officialLink": "https://www.st-andrews.ac.uk/study/scholarships/scholarships-catalogue/undergraduate-scholarships/international-undergraduate-scholarship/",
   "applicationLink": "https://www.st-andrews.ac.uk/study/scholarships/scholarships-catalogue/undergraduate-scholarships/university-of-st-andrews-international-undergraduate-scholarships/",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Open now (opened 17 Aug 2026; closes 27 Jan 2027). Official page confirms eligibility, inclusion of Computer Science and the application route. Award value not yet confirmed (due December 2026), so not Verified. Outcomes by mid-March 2027. Contact: ugscholarships@st-andrews.ac.uk. Replaces Heriot-Watt International Merit Scholarship, which has no confirmed 2027 window (see Watchlist sheet).",
   "watchlist": false
  },
  {
   "id": "SCH-010",
   "name": "University of Bristol Think Big Undergraduate Scholarship (2027 entry)",
   "country": "United Kingdom",
   "provider": "University of Bristol",
   "studyLevel": "Undergraduate (up to four years of study); postgraduate taught also covered by Think Big. Eligible undergraduate course list not yet complete.",
   "levels": [
    "undergraduate-applicant",
    "postgraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "partial"
   ],
   "indian": "Conditional",
   "nationalities": "Overseas fee-status students. No nationality restriction stated; Indian applicants qualify if classed as overseas fee status.",
   "categories": "Overseas fee-status applicants who have applied for an eligible undergraduate or master's course and hold an application ID.",
   "academic": "Not confirmed (course entry requirements apply). CBSE Class 12 eligibility: Not confirmed.",
   "income": "Not stated on official page.",
   "courses": "Eligible undergraduate courses: Not confirmed. Official page says more undergraduate awards will be added by end of November 2026. Computer Science: Not confirmed.",
   "funding": "Partial. Value stated per year; whether it covers tuition or living costs: Not confirmed.",
   "amount": "GBP 6,500 or GBP 13,000 per year, for up to four years of study.",
   "openingISO": "2026-10-27",
   "openingNote": null,
   "deadlineISO": "2027-03-19",
   "deadlineNote": null,
   "admission": "Yes. Must apply to study at Bristol and receive an application ID before starting the scholarship application.",
   "nomination": "Yes. Think Big application form (one form covers the international scholarships you are eligible for).",
   "documents": "Think Big application form; supporting information per Think Big application guidance (detailed list Not confirmed).",
   "officialLink": "https://www.bristol.ac.uk/international/fees-finance/scholarships/",
   "applicationLink": "https://www.bristol.ac.uk/international/fees-finance/scholarships/application-guidance/",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Applications open today, 27 Oct 2026, 10:00 UK time, and close 19 Mar 2027, 13:00 UK time (official timeline). Undergraduate award list is incomplete until end-November 2026, so course eligibility, including Computer Science, cannot be confirmed yet. Think Big terms and conditions linked on the official page; not reviewed in detail. Replaces Nanyang Global Scholarship (see Watchlist sheet).",
   "watchlist": false
  },
  {
   "id": "SCH-012",
   "name": "PM-USP - Central Sector Scheme Of Scholarship For College And University\nStudents (CSSS) (Merit Based Scheme)",
   "country": "India",
   "provider": "Department of Higher Education, Ministry of Education, Government of India",
   "studyLevel": "Undergraduate (UG) and postgraduate (PG), subject to scheme conditions",
   "levels": [
    "current-undergraduate",
    "current-postgraduate"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "government",
    "merit",
    "need",
    "partial",
    "living"
   ],
   "indian": "Yes",
   "nationalities": "Indian students",
   "categories": "Meritorious students from families meeting the income limit who are pursuing regular college or university courses. Selection is based on Class 12 board performance and allocated board-wise slots. Diploma students and students who took a gap after Class 12 are ineligible under the published scheme FAQ.",
   "academic": "Fresh: above the 80th percentile among successful candidates in the relevant Class 12 board stream (board-wise slots). Renewal: at least 50% in the annual exam and 75% attendance.",
   "income": "Up to Rs 4,50,000 per year from all sources (scheme guidelines). Income certificate required for fresh applicants only.",
   "courses": "Regular degree and postgraduate courses at AICTE/UGC-recognised institutions. Diploma, correspondence and distance-learning courses are not eligible.",
   "funding": "Financial assistance toward day-to-day educational and living expenses; it is not generally a full tuition-fee scholarship.",
   "amount": "Rs 12,000 per year for the first three years of graduation; Rs 20,000 per year at postgraduate level. Four- or five-year professional courses: Rs 20,000 in the 4th and 5th years (technical B.Tech/B.Engg: Rs 12,000 for years 1-3, Rs 20,000 in year 4).",
   "openingISO": "2026-06-01",
   "openingNote": "1 June 2026 (2026-27 NSP cycle)",
   "deadlineISO": "2026-10-31",
   "deadlineNote": "Renewal: 31 Oct 2026 student application (NSP official announcement). Institute verification 15 Nov 2026; L2 verification 30 Nov 2026. Fresh-application dates for 2026-27: not announced.",
   "admission": "Yes. Students must be enrolled in an eligible regular college or university course.",
   "nomination": "No separate nomination; applications are submitted through the National Scholarship Portal and verified by the relevant institution and authorities.",
   "documents": "Class 12 marksheet, family income certificate, bank account details, Aadhaar/OTR details, college or university admission/enrolment details, and any documents requested by the current portal or institution. Confirm the exact checklist for the application year.",
   "officialLink": "https://nitkkr.ac.in/wp-content/uploads/2025/04/Central-Sector-Scheme-Of-Scholarships-For-College-And-University-Students.pdf (institute-hosted copy of Ministry guidelines)",
   "applicationLink": "https://scholarships.gov.in",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Verified against the NSP scheme announcement (scholarships.gov.in): renewal student deadline 31 Oct 2026, institute verification 15 Nov 2026, L2 verification 30 Nov 2026. Earlier 30 Sep 2026 dates came from third-party sites and are superseded. Fresh-application dates have not been announced, so fresh applicants should watch NSP. Income limit Rs 4.5 lakh, 80th percentile rule for fresh applicants, and amounts Rs 12,000 (UG) and Rs 20,000 (PG) confirmed by official-linked guidelines. Diploma, correspondence and distance courses excluded.",
   "watchlist": false
  },
  {
   "id": "SCH-013",
   "name": "Innovation in Science Pursuit for Inspired Research (INSPIRE) – Scholarship for Higher Education (SHE)",
   "country": "India",
   "provider": "Department of Science and Technology (DST), Ministry of Science and Technology, Government of India",
   "studyLevel": "Undergraduate and postgraduate science studies, including B.Sc., B.S., four-year B.Sc. with Research, Integrated M.Sc. and Integrated M.S.; subject to scheme conditions.",
   "levels": [
    "class-12",
    "undergraduate-applicant"
   ],
   "subjects": [
    "Science & Mathematics"
   ],
   "types": [
    "government",
    "merit",
    "partial",
    "living"
   ],
   "indian": "Yes",
   "nationalities": "Indian students; check the current call guidelines for any specific nationality or residency conditions.",
   "categories": "Generally, students aged 17–22 who meet one of the scheme’s academic merit pathways and enrol in an eligible basic or natural science course. Pathways include top 1% of the Class 12 board examination, specified high ranks in eligible competitive examinations, and qualifying recognised scholarship, talent-search or International Science Olympiad awards.",
   "academic": "One eligible route is to be within the top 1% of successful students in the relevant Class 12 board examination. Other routes include qualifying ranks in specified examinations or recognised awards listed in the official FAQ. Applicants must also enrol in an eligible science degree.",
   "income": "No family-income ceiling is specified",
   "courses": "Basic and natural sciences, including Physics, Chemistry, Mathematics, Biology, Statistics, Geology, Astrophysics, Astronomy, Electronics, Botany, Zoology, Biochemistry, Anthropology, Microbiology, Geophysics, Geochemistry, Atmospheric Sciences and Oceanic Sciences. Certain professional and applied courses—including Engineering, Medicine, Agriculture, Biotechnology, Computer Science and IT—are excluded under the published FAQ. Check the current course list before confirming eligibility.",
   "funding": "Scholarship assistance for eligible science studies plus an annual mentorship grant for a summer research project. It is not advertised as a full tuition-fee scholarship",
   "amount": "₹80,000 per year in total:\n- ₹60,000 annual scholarship assistance (₹5,000 per month).\n- ₹20,000 annual mentorship grant for a summer research project.\nSupport is available for up to five years or until course completion, whichever comes first, subject to continuation requirements",
   "openingISO": null,
   "openingNote": "Not confirmed",
   "deadlineISO": null,
   "deadlineNote": "Not confirmed for 2026-27. Previous cycles: 2024 portal open 1 Sep to 15 Oct; 2023 closed 9 Nov. Third-party listings say the 2025-26 cycle closed 31 Dec 2025.",
   "admission": "Yes. Applicants must have completed Class 12 in the relevant year and enrolled in an eligible B.Sc., B.S. or integrated science degree in that same year.",
   "nomination": "No general separate nomination is specified for the standard application route. A prescribed endorsement certificate signed by the college principal, institute director or university registrar is required. Some eligibility pathways depend on recognised awards or examination results.",
   "documents": "Class 12 marksheet; Class 10 marksheet or certificate as date-of-birth proof; prescribed endorsement certificate signed by the institution; eligibility/advisory note if issued by the board (optional); and relevant examination rank or award certificate if applying through that pathway. Check the current application instructions for any additional documents",
   "officialLink": "https://www.online-inspire.gov.in",
   "applicationLink": "https://www.online-inspire.gov.in",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Confirmed: Rs 80,000 per year (Rs 60,000 scholarship in Rs 5,000 monthly instalments plus Rs 20,000 mentorship/summer project grant); up to five years; no income ceiling; Computer Science and IT are not covered under the published FAQ (several sources agree). Correction: the '10,000 scholarships' figure is contradicted by DST-linked sources, which state 12,000 per year; 12,000 used. Continuation requires at least 60% marks or GPA 7.0. Check the live portal for 2026-27 dates.",
   "watchlist": false
  },
  {
   "id": "SCH-016",
   "name": "Prime Minister’s Scholarship Scheme for Central Armed Police Forces and Assam Rifles (PMSS)",
   "country": "India",
   "provider": "Ministry of Home Affairs, Government of India, under the aegis of the National Defence Fund.",
   "studyLevel": "Undergraduate professional degree programmes; certain postgraduate professional courses, such as MBA and MCA, may qualify when they meet the scheme’s first-professional-degree conditions.",
   "levels": [
    "current-undergraduate",
    "professional"
   ],
   "subjects": [
    "Engineering",
    "Medicine & health",
    "Business & Economics"
   ],
   "types": [
    "government",
    "partial"
   ],
   "indian": "Yes",
   "nationalities": "Indian students who satisfy the scheme’s dependant and other eligibility requirements.",
   "categories": "Eligible wards or widows of serving or retired Central Armed Police Forces (CAPFs) and Assam Rifles personnel, including specified categories of personnel who died in service, were disabled due to service-related causes, or received gallantry awards. Priority categories apply. Civilian employees’ wards are excluded",
   "academic": "Fresh applicants must have secured at least 60% marks in the Minimum Entry Qualification (MEQ)—Class 12, diploma, graduation or equivalent, depending on the course. Renewal applicants must pass each subsequent academic year with at least 50% marks. Only eligible first professional degree courses are covered.",
   "income": "No family-income ceiling is specified in the official revised guidelines reviewed.",
   "courses": "Recognised first professional degree courses, including engineering, medicine, dentistry, veterinary science, BBA, BCA, B.Pharm, B.Sc. Nursing, agriculture and other eligible professional courses. MBA and MCA may qualify subject to the scheme rules. Correspondence/distance courses and study abroad are excluded",
   "funding": "Financial assistance paid directly into the selected student’s bank account. It is a fixed scholarship rather than a full tuition-fee reimbursement.",
   "amount": "Girls: ₹36,000 per year (₹3,000 per month).\n\n\n\nBoys: ₹30,000 per year (₹2,500 per month).",
   "openingISO": "2026-06-01",
   "openingNote": null,
   "deadlineISO": "2026-10-31",
   "deadlineNote": "31 October 2026 for the 2026–27 cycle. Institute verification closes on 15 November 2026, and district/state/other nodal verification closes on 30 November 2026",
   "admission": "Yes. Applicants must be pursuing an eligible professional degree course and satisfy the scheme’s entry qualification and admission requirements.",
   "nomination": "No separate nomination is specified. However, applications require service-related documentation and verification by the educational institution and the relevant CAPF/Assam Rifles authorities.",
   "documents": "MEQ marksheet; service certificate issued by the Head of Office for serving personnel, where applicable; PPO/discharge certificate or book for the relevant categories; death certificate for applicable deceased-personnel categories; disability certificate for applicable disability categories; gallantry-award certificate where applicable; Aadhaar-linked bank account details; and other information requested by NSP",
   "officialLink": "https://scholarships.gov.in (NSP; MHA Welfare and Rehabilitation Board guidelines, official PDF not re-checked)",
   "applicationLink": "https://scholarships.gov.in",
   "lastVerified": "2026-10-27",
   "verification": "Partially Verified",
   "notes": "Confirmed: Rs 36,000 per year for girls (Rs 3,000 per month) and Rs 30,000 per year for boys (Rs 2,500 per month); 2,000 fresh awards per year, split 1,000 each, plus renewals; 60% minimum in MEQ for fresh applicants; no income ceiling in the revised guidelines; application window 1 June to 31 Oct 2026; institute verification 15 Nov; nodal verification 30 Nov. Corrections: Last Verified Date was wrongly 2027-10-27 (now 2026-10-27); the 'two children per family' and 'no concurrent scholarship' limits were not confirmed and are removed. Verify on NSP.",
   "watchlist": false
  },
  {
   "id": "W-01",
   "name": "Heriot-Watt University International Merit Scholarship",
   "country": "United Kingdom",
   "provider": "Heriot-Watt University",
   "studyLevel": "Undergraduate and postgraduate taught",
   "levels": [
    "undergraduate-applicant",
    "postgraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "merit",
    "partial"
   ],
   "indian": "Not confirmed",
   "nationalities": "International (non-EU fee-paying) students. Eligibility varies by region; India-specific rule for 2027: Not confirmed.",
   "categories": "Eligibility varies by region; contact regional team.",
   "academic": "Not confirmed. Official page refers to 2026 intakes only.",
   "income": "Not confirmed",
   "courses": "Not confirmed (third-party listing says any discipline; official course list not confirmed).",
   "funding": "Partial. Usually a partial fee abatement for first year only, unless stated in offer letter.",
   "amount": "Varies by region; not confirmed for 2027.",
   "openingISO": null,
   "openingNote": "Not confirmed",
   "deadlineISO": null,
   "deadlineNote": "Not confirmed",
   "admission": "Not confirmed",
   "nomination": "No.",
   "documents": "Not confirmed",
   "officialLink": "https://www.hw.ac.uk/study/fees-and-funding/scholarships-and-bursaries/international-merit-scholarship",
   "applicationLink": "Not confirmed",
   "lastVerified": "2026-10-27",
   "verification": "Needs Verification",
   "notes": "Official page covers January and September 2026 intakes (last updated 27 Nov 2025). No 2027 window published. Third-party sites show 'deadline not specified'. Moved here because it fails the confirmed-window rule. Replaced by SCH-009 (St Andrews). Re-check once Heriot-Watt publishes 2027 intake details.",
   "watchlist": true
  },
  {
   "id": "W-02",
   "name": "Nanyang Global Scholarship (Nanyang Technological University, Singapore)",
   "country": "Singapore",
   "provider": "Nanyang Technological University (NTU)",
   "studyLevel": "Undergraduate, full-time (outstanding freshmen)",
   "levels": [
    "class-12",
    "undergraduate-applicant"
   ],
   "subjects": [
    "Any subject"
   ],
   "types": [
    "university",
    "merit",
    "partial",
    "full"
   ],
   "indian": "Conditional",
   "nationalities": "Open to all nationalities (official NTU page).",
   "categories": "Outstanding freshmen; strong leadership and co-curricular record. Applicants with Year 12 equivalent results (including India Standard 12) use a separate route.",
   "academic": "Outstanding results in A-Level, Singapore polytechnic diploma, NUS High School Diploma or IB, or Year 12 equivalent. CBSE eligibility via Year 12 route: Not confirmed for 2027.",
   "income": "Not stated.",
   "courses": "Full-time NTU undergraduate programmes. Computer Science eligibility for this scholarship: Not confirmed.",
   "funding": "Partial to full: full subsidised tuition (after MOE tuition grant), plus allowances.",
   "amount": "Subsidised tuition (after tuition grant); living allowance S$6,500 per year; accommodation allowance up to S$2,000 per year (NTU hostel residents); travel grant up to S$8,000 (overseas programme); computer allowance S$2,000 (one-off).",
   "openingISO": null,
   "openingNote": "Not confirmed (official NTU important dates list admission outcome for India Standard 12 in end July 2027, but no scholarship closing date for that route).",
   "deadlineISO": null,
   "deadlineNote": "Not confirmed",
   "admission": "Yes. Must apply for NTU admission first; scholarship application follows.",
   "nomination": "No.",
   "documents": "Scholarship application (online); personal essay up to 250 words; passport-size photo; school teacher appraisal (online); transcripts; co-curricular activities record; passport. Full list for Year 12 route: Not confirmed.",
   "officialLink": "https://www.ntu.edu.sg/admissions/undergraduate/scholarships-and-awards/scholarship-opportunities/detail/nanyang-scholarship",
   "applicationLink": "https://wis.ntu.edu.sg/ords/apex/r/scholarship/scholarship/logins?session",
   "lastVerified": "2026-10-27",
   "verification": "Needs Verification",
   "notes": "Official page confirms the name 'Nanyang Global Scholarship' and open-to-all-nationalities eligibility, but NTU's official dates page gives no scholarship deadline for India Standard 12 applicants. Third-party sites give 24 Mar 2027 or about 15 Jan 2027; not used. Moved here because it fails the confirmed-window rule. Replaced by SCH-010 (Bristol). Re-check NTU important dates once published.",
   "watchlist": true
  },
  {
   "id": "W-03",
   "name": "Monash University Faculty of IT International Merit Scholarship",
   "country": "Australia",
   "provider": "Monash University, Faculty of Information Technology",
   "studyLevel": "Undergraduate (Bachelor of IT; Bachelor of Computer Science; Bachelor of Computer Science Advanced (Honours))",
   "levels": [
    "class-12",
    "undergraduate-applicant"
   ],
   "subjects": [
    "Computer Science & IT"
   ],
   "types": [
    "university",
    "merit",
    "partial",
    "tuition"
   ],
   "indian": "Yes",
   "nationalities": "Citizens of India, Sri Lanka or Bangladesh currently studying there (official page).",
   "categories": "Completing final year (equivalent to Australian Year 12) offshore.",
   "academic": "ATAR or international equivalent threshold: sources disagree (90+ on third-party sites; 94+ on IDP). Official threshold: Not confirmed.",
   "income": "Not stated.",
   "courses": "Bachelor of Information Technology (C2000); Bachelor of Computer Science (C2001); Bachelor of Computer Science Advanced (Honours) (C3001).",
   "funding": "Partial: 20% off tuition fees for the duration of the course.",
   "amount": "20% of tuition fees for the course duration.",
   "openingISO": null,
   "openingNote": "Not confirmed. No separate application; awards assessed automatically on offer.",
   "deadlineISO": null,
   "deadlineNote": "Not confirmed",
   "admission": "Yes. Must be enrolling in, or holding an offer for, one of the listed IT degrees.",
   "nomination": "No. Automatically assessed.",
   "documents": "Not confirmed",
   "officialLink": "https://www.monash.edu/study/fees-scholarships/scholarships/find-a-scholarship/faculty-of-it-international-merit-scholarship-6232",
   "applicationLink": "Not applicable (no separate application).",
   "lastVerified": "2026-10-27",
   "verification": "Needs Verification",
   "notes": "Strong Computer Science fit for Indian citizens finishing Year 12 offshore, but no dated 2027 window is published. Awards are automatic on admission, so the timing depends on Monash's 2027 admissions dates. Sources disagree on the number of awards (10 vs 20) and the ATAR threshold (90 vs 94). Not added to the database. Re-check monash.edu once the 2027 timeline is published.",
   "watchlist": true
  }
 ]
};
