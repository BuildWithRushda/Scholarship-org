# Publishing the Scholarship.org Education Initiative website (free)

This site is plain HTML, CSS and JavaScript. It needs no paid service, database or server.
We will host it on **GitHub Pages**, which gives you a free address like
`https://YOUR-USERNAME.github.io/scholarship-org/`.

## Before you start: the two values you need to add

Open `config.js` in any text editor (Notepad works on Windows) and find:

- `surveyUrl: ""` : paste your real survey link between the quotes, e.g. `surveyUrl: "https://forms.gle/abc123",`
- `contactEmail: ""` : paste your real contact email between the quotes, e.g. `contactEmail: "hello@example.org",`

Leave them empty if you do not have them yet. The site will say the survey link and email are coming soon.
Save the file. Nothing else in the site needs editing.

---

## Part A: Using an Android phone

1. **Create a free GitHub account** at https://github.com/signup using your email. Verify the email when prompted.
2. **Create a new repository.**
   - Tap the **+** at the top right, then **New repository**.
   - Repository name: `scholarship-org` (lowercase, no spaces).
   - Choose **Public**.
   - Tick **Add a README file**, then tap **Create repository**.
3. **Upload the files.** On a phone this is easiest with the desktop-site view:
   - Open the repository in Chrome. Tap the three dots (⋮) and tick **Desktop site**.
   - Tap **Add file**, then **Upload files**.
   - Select the files: `index.html`, `styles.css`, `script.js`, `config.js`, and the `assets` folder.
     (Android may ask you to select files one by one. If it does not accept folders, use Part B on a laptop instead.)
   - Scroll down and tap **Commit changes**.
4. **Turn on GitHub Pages.**
   - Tap **Settings** (in the repository's top bar, may be under the ⋮ menu).
   - Tap **Pages** in the left menu.
   - Under **Build and deployment**, set **Source** to **Deploy from a branch**.
   - Under **Branch**, choose **main** and **/ (root)**, then tap **Save**.
5. **Wait 1 to 3 minutes**, then refresh the Pages screen. It will show your live address. Open it to check.

## Part B: Using an older Windows laptop

1. **Create a free GitHub account** at https://github.com/signup and verify your email.
2. **Create the repository.** Click **+** (top right), then **New repository**.
   - Name: `scholarship-org`. Choose **Public**. Tick **Add a README file**. Click **Create repository**.
3. **Upload the files.**
   - Unzip the downloaded `scholarship-org-website.zip` first (right-click, **Extract All**).
   - In the repository, click **Add file**, then **Upload files**.
   - Drag in `index.html`, `styles.css`, `script.js`, `config.js` and the whole `assets` folder.
   - Scroll down, click **Commit changes**.
4. **Turn on GitHub Pages.**
   - Click **Settings**, then **Pages** in the left menu.
   - Under **Build and deployment**, choose **Deploy from a branch**.
   - Branch: **main**, folder **/ (root)**. Click **Save**.
5. **Wait 1 to 3 minutes**, refresh, and your live link appears at the top of the Pages screen.

## Updating the site later

- To change the survey link or email: open the repository, click `config.js`, click the pencil icon, edit the value, then **Commit changes**.
- The live site updates within a few minutes.

## Using your own domain later (optional, not needed now)

You can add a custom domain in Settings → Pages later. Do not buy one until you decide to. The free GitHub address works well for now.

## Troubleshooting

- **Page shows 404:** wait a few more minutes, or confirm Settings → Pages shows branch `main` and folder `/ (root)`.
- **Styles look missing:** make sure the `assets` folder and `styles.css` were uploaded in the same place as `index.html`.
- **Survey button still inactive:** check that the link in `config.js` is inside the quotes and starts with `https://`.

## Accounts, saving, reminders and the tracker

These need a free Supabase project and, for reminder emails, a Git-based Netlify deploy.
Follow **SETUP-ACCOUNTS.md** in this folder. Until then the site works as a directory, and
account pages show a "not connected yet" message.

Deploy note: drag-and-drop deploys on Netlify do not run the daily reminder job. Connect
the project to a GitHub repository for scheduled reminders.
