/*
  Daily job: sends deadline reminder emails.
  Runs on the schedule in netlify.toml (03:30 UTC = 09:00 India time).

  Needs these Netlify environment variables (Site settings > Environment variables, mark as secret):
    SUPABASE_URL                 your Supabase project URL
    SUPABASE_SERVICE_ROLE_KEY    the service_role key. NEVER put this in the website files.
    RESEND_API_KEY               API key from your email provider (Resend)
    REMINDER_FROM_EMAIL          a sender address your email provider allows

  If any variable is missing, the job does nothing and says so.
*/
const fs = require("fs");
const path = require("path");
const vm = require("vm");

function loadRecords() {
  const candidates = [
    path.join(__dirname, "../../data/scholarships.js"),
    path.join(process.cwd(), "data/scholarships.js")
  ];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      const sandbox = { window: {} };
      vm.runInNewContext(fs.readFileSync(file, "utf8"), sandbox);
      return sandbox.window.SCHOLARSHIP_DATA.records;
    }
  }
  throw new Error("scholarships.js was not found. Check included_files in netlify.toml.");
}

function addDays(iso, n) {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

function fmt(iso) {
  return new Date(iso + "T00:00:00Z").toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
}

exports.handler = async function () {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const mailKey = process.env.RESEND_API_KEY;
  const from = process.env.REMINDER_FROM_EMAIL;
  if (!url || !key || !mailKey || !from) {
    return { statusCode: 200, body: "Reminder email is not configured. Nothing was sent." };
  }

  const records = loadRecords();
  const byId = {};
  records.forEach((r) => { byId[r.id] = r; });

  // Today's date in India time, because reminders are planned for 9:00 am IST.
  const today = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10);
  const headers = { apikey: key, Authorization: "Bearer " + key };

  const res = await fetch(url + "/rest/v1/reminders?enabled=eq.true&select=*", { headers });
  if (!res.ok) throw new Error("Could not read reminders: " + res.status);
  const reminders = await res.json();

  let sent = 0, skipped = 0;
  for (const rem of reminders) {
    const rec = byId[rem.scholarship_id];
    // Skip when the scholarship or its deadline is no longer confirmed, or the deadline changed.
    // Those reminders need the student to review them first. Never send a reminder for a guessed date.
    if (!rec || !rec.deadlineISO || rec.deadlineISO !== rem.deadline_snapshot) { skipped++; continue; }
    const due = addDays(rec.deadlineISO, -rem.offset_days);
    if (due !== today) continue;
    if (rem.last_sent_at && rem.last_sent_at.slice(0, 10) === today) continue;

    const userRes = await fetch(url + "/auth/v1/admin/users/" + rem.user_id, { headers });
    if (!userRes.ok) { skipped++; continue; }
    const user = await userRes.json();
    if (!user.email) { skipped++; continue; }

    const when = rem.offset_days === 0 ? "today" : "in " + rem.offset_days + (rem.offset_days === 1 ? " day" : " days");
    const text = [
      "Reminder: the deadline for " + rec.name + " is " + when + " (" + fmt(rec.deadlineISO) + ").",
      "",
      "Check the closing time and time zone, and confirm the requirements, on the official page:",
      rec.applicationLink && /^https?:\/\//.test(rec.applicationLink) ? rec.applicationLink : rec.officialLink,
      "",
      "Scholarship.org Education Initiative provides information and guidance only. We do not guarantee scholarships or awards.",
      "To turn off this reminder, use your dashboard on the website."
    ].join("\n");

    const mail = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + mailKey, "Content-Type": "application/json" },
      body: JSON.stringify({ from: from, to: [user.email], subject: "Deadline reminder: " + rec.name, text: text })
    });
    if (!mail.ok) { skipped++; continue; }

    await fetch(url + "/rest/v1/reminders?id=eq." + rem.id, {
      method: "PATCH",
      headers: Object.assign({ "Content-Type": "application/json", Prefer: "return=minimal" }, headers),
      body: JSON.stringify({ last_sent_at: new Date().toISOString() })
    });
    sent++;
  }

  return { statusCode: 200, body: "Reminders sent: " + sent + ". Skipped: " + skipped + "." };
};
