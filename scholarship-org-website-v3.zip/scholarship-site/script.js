(function () {
  "use strict";

  var config = window.SITE_CONFIG || {};

  // ---- Survey link -------------------------------------------------
  var surveyUrl = (config.surveyUrl || "").trim();
  var surveyButtons = document.querySelectorAll("[data-survey-link]");
  var surveyStatus = document.getElementById("survey-status");

  surveyButtons.forEach(function (btn) {
    if (surveyUrl) {
      btn.href = surveyUrl;
      btn.target = "_blank";
      btn.rel = "noopener noreferrer";
      btn.removeAttribute("aria-disabled");
      btn.classList.remove("is-disabled");
    } else {
      btn.removeAttribute("href");
      btn.setAttribute("aria-disabled", "true");
      btn.classList.add("is-disabled");
    }
  });

  if (surveyStatus) {
    surveyStatus.textContent = surveyUrl
      ? ""
      : "The survey link is not available yet. It will appear here once the survey is ready.";
  }

  // ---- Contact email -----------------------------------------------
  var contactEmail = (config.contactEmail || "").trim();
  document.querySelectorAll("[data-contact-link]").forEach(function (link) {
    if (contactEmail) {
      link.href = "mailto:" + contactEmail;
      link.textContent = contactEmail;
    } else {
      link.removeAttribute("href");
      link.textContent = "Email to be added";
    }
  });

  // ---- Footer year ---------------------------------------------------
  var year = document.getElementById("year");
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  // ---- Mobile menu ----------------------------------------------------
  var toggle = document.querySelector(".menu-toggle");
  var menu = document.getElementById("site-menu");
  var mobileQuery = window.matchMedia("(max-width: 719px)");

  function setMenu(open) {
    toggle.setAttribute("aria-expanded", String(open));
    menu.hidden = !open;
  }

  if (toggle && menu) {
    if (mobileQuery.matches) {
      setMenu(false);
    }

    toggle.addEventListener("click", function () {
      setMenu(toggle.getAttribute("aria-expanded") !== "true");
    });

    // Close the menu after choosing a link on small screens.
    menu.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        if (mobileQuery.matches) {
          setMenu(false);
        }
      });
    });

    // Close with the Escape key and return focus to the menu button.
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
        setMenu(false);
        toggle.focus();
      }
    });
  }
})();
