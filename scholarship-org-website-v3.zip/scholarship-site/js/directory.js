/* Scholarship directory: reads filters from the URL so every filtered view can be shared. */
(function () {
  "use strict";
  var SU = window.SU;
  if (!SU) return;

  var form = document.getElementById("filter-form");
  var results = document.getElementById("results");
  var meta = document.getElementById("results-meta");
  if (!form || !results) return;

  var params = new URLSearchParams(window.location.search);
  function val(name) { return params.get(name) || ""; }

  var fields = {
    q: val("q"),
    level: val("level"),
    country: val("country"),
    subject: val("subject"),
    funding: val("funding"),
    status: val("status"),
    deadline: val("deadline") || "any",
    indian: val("indian") || "any",
    category: val("category")
  };

  // Fill the form from the URL.
  form.elements["q"].value = fields.q;
  SU.fillSelect(form.elements["level"], [["", "All education levels"]].concat(SU.LEVELS), fields.level);
  var countryOpts = [["", "All countries"]].concat(SU.countries().map(function (c) { return [c, c]; }));
  SU.fillSelect(form.elements["country"], countryOpts, fields.country);
  SU.fillSelect(form.elements["subject"], [["", "All subjects"]].concat(SU.SUBJECTS.map(function (s) { return [s, s]; })), fields.subject);
  SU.fillSelect(form.elements["funding"], [["", "Any funding type"]].concat(SU.FUNDING), fields.funding);
  SU.fillSelect(form.elements["status"], [["", "Any status"]].concat(SU.STATUSES.map(function (s) { return [s, s]; })), fields.status);
  SU.fillSelect(form.elements["deadline"], SU.DEADLINES, fields.deadline);
  SU.fillSelect(form.elements["indian"], [["any", "Any eligibility"]].concat(SU.INDIAN), fields.indian);
  SU.fillSelect(form.elements["category"], SU.CATEGORIES, fields.category);

  function render() {
    var today = SU.todayISO();
    var list = SU.filter(SU.records, fields, today);
    results.innerHTML = "";

    if (meta) {
      meta.textContent = "Showing " + list.length + " of " + SU.records.length + " entries in the verified database.";
    }

    if (!list.length) {
      var empty = SU.el("div", "empty-state");
      empty.appendChild(SU.el("p", null, "No scholarships match these filters."));
      empty.appendChild(SU.el("p", "muted", "Try removing a filter, or open Browse by category for a broader view."));
      results.appendChild(empty);
      return;
    }

    var grid = SU.el("div", "card-grid");
    list.forEach(function (r) { grid.appendChild(SU.renderCard(r, today)); });
    results.appendChild(grid);
  }

  // Clear, and changes to filters, update the URL so results can be bookmarked.
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var data = new FormData(form);
    var next = new URLSearchParams();
    data.forEach(function (v, k) {
      if (v && v !== "any") next.set(k, v);
    });
    var qs = next.toString();
    window.location.href = "scholarships.html" + (qs ? "?" + qs : "");
  });

  var clear = document.getElementById("clear-filters");
  if (clear) clear.addEventListener("click", function () { window.location.href = "scholarships.html"; });

  results.textContent = "";
  var loading = SU.el("p", "loading", "Loading scholarships…");
  results.appendChild(loading);
  render();
})();
