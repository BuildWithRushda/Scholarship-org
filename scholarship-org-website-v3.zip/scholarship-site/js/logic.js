/* Pure logic for reminders, recommendations and application statuses. No network access. */
(function () {
  "use strict";

  var OFFSETS = [30, 14, 7, 3, 1, 0];
  var OFFSET_LABEL = {
    30: "30 days before",
    14: "14 days before",
    7: "7 days before",
    3: "3 days before",
    1: "1 day before",
    0: "On the deadline day"
  };
  var APP_STATUSES = ["Interested", "Preparing Documents", "Ready to Apply", "Applied", "Awarded", "Not Pursuing"];

  function addDays(iso, n) {
    var d = new Date(iso + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }

  // Reminder date for an offset. Returns null when the deadline is not confirmed.
  function reminderDate(deadlineISO, offset) {
    return deadlineISO ? addDays(deadlineISO, -offset) : null;
  }

  // True when the deadline on the site no longer matches the one the reminder was set for.
  function deadlineChanged(snapshot, currentISO) {
    return !!snapshot && snapshot !== (currentISO || null);
  }

  // Preliminary matching against the eligibility fields in the database.
  // Hard filters: education level and study destination (when the student has set them).
  // Soft matches: subject and funding preference are listed as reasons.
  function recommend(profile, records, today) {
    profile = profile || {};
    var SU = window.SU;
    var out = [];
    records.forEach(function (r) {
      var status = SU.statusOf(r, today);
      if (status === "Needs Verification" || status === "Closed") return;
      var reasons = [];
      if (profile.education_level) {
        if (r.levels.indexOf(profile.education_level) === -1) return;
        reasons.push("education level");
      }
      if (profile.study_destination && profile.study_destination !== "Any") {
        if (r.country !== profile.study_destination) return;
        reasons.push("study destination");
      }
      if (profile.subject && (r.subjects.indexOf(profile.subject) !== -1 || r.subjects.indexOf("Any subject") !== -1)) {
        reasons.push("subject");
      }
      var prefs = profile.funding_preferences || [];
      if (prefs.length && r.types.some(function (t) { return prefs.indexOf(t) !== -1; })) {
        reasons.push("funding preference");
      }
      out.push({
        record: r,
        status: status,
        reasons: reasons,
        note: (profile.home_country === "India" && r.indian === "Not confirmed") ? "Eligibility for Indian citizens is not confirmed." : ""
      });
    });
    out.sort(function (a, b) {
      if (b.reasons.length !== a.reasons.length) return b.reasons.length - a.reasons.length;
      var da = a.record.deadlineISO, db = b.record.deadlineISO;
      if (da && db) return da < db ? -1 : (da > db ? 1 : 0);
      if (da) return -1;
      if (db) return 1;
      return 0;
    });
    return out;
  }

  window.SULOGIC = {
    OFFSETS: OFFSETS,
    OFFSET_LABEL: OFFSET_LABEL,
    APP_STATUSES: APP_STATUSES,
    addDays: addDays,
    reminderDate: reminderDate,
    deadlineChanged: deadlineChanged,
    recommend: recommend
  };
})();
