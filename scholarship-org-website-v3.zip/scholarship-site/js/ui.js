/* Shared scholarship logic: labels, status, filtering, and card rendering.
   Reads window.SCHOLARSHIP_DATA from data/scholarships.js. */
(function () {
  "use strict";

  var records = (window.SCHOLARSHIP_DATA && window.SCHOLARSHIP_DATA.records) || [];

  var LEVELS = [
    ["class-11", "Class 11"],
    ["class-12", "Class 12"],
    ["gap-year", "Gap-year students"],
    ["undergraduate-applicant", "Undergraduate applicants"],
    ["current-undergraduate", "Current undergraduate students"],
    ["postgraduate-applicant", "Postgraduate applicants"],
    ["current-postgraduate", "Current postgraduate students"],
    ["research", "Research students"],
    ["professional", "Professional and skill-based courses"]
  ];

  var SUBJECTS = [
    "Any subject", "Computer Science & IT", "Engineering",
    "Science & Mathematics", "Business & Economics", "Medicine & health"
  ];

  var FUNDING = [
    ["full", "Full scholarship"],
    ["partial", "Partial scholarship"],
    ["tuition", "Tuition-fee assistance"],
    ["living", "Living-cost assistance"]
  ];

  var STATUSES = ["Open", "Officially Upcoming", "Closed", "Cycle Unconfirmed", "Needs Verification"];

  var DEADLINES = [
    ["any", "Any deadline"],
    ["30", "Closing within 30 days"],
    ["90", "Closing within 90 days"],
    ["later", "Closing after 90 days"],
    ["none", "No confirmed deadline"]
  ];

  var INDIAN = [
    ["yes", "Yes"],
    ["conditional", "Conditional"],
    ["unconfirmed", "Not confirmed"]
  ];

  var CATEGORIES = [
    ["", "All scholarships"],
    ["indian", "Indian government and Indian institution scholarships"],
    ["international", "International and study-abroad scholarships"]
  ];

  var STATUS_CLASS = {
    "Open": "status-open",
    "Officially Upcoming": "status-upcoming",
    "Closed": "status-closed",
    "Cycle Unconfirmed": "status-unconfirmed",
    "Needs Verification": "status-needs"
  };

  var STATUS_HELP = {
    "Open": "The official application window is confirmed and open today.",
    "Officially Upcoming": "The official window is confirmed but has not opened yet.",
    "Closed": "The confirmed deadline has passed.",
    "Cycle Unconfirmed": "No official application window for the current cycle is confirmed.",
    "Needs Verification": "This entry is not yet fully checked. Do not rely on it."
  };

  var TYPE_LABELS = {
    merit: "Merit-based", need: "Need-based", full: "Full", partial: "Partial",
    tuition: "Tuition-fee assistance", living: "Living-cost assistance",
    government: "Government", university: "University", "private": "Foundation and private"
  };

  var LEVEL_LABEL = {};
  LEVELS.forEach(function (l) { LEVEL_LABEL[l[0]] = l[1]; });

  function pad(n) { return (n < 10 ? "0" : "") + n; }

  function todayISO() {
    var d = new Date();
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function fmtDate(iso) {
    if (!iso) return null;
    var d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  }

  function daysUntil(iso, today) {
    return Math.round((new Date(iso + "T00:00:00") - new Date(today + "T00:00:00")) / 86400000);
  }

  function statusOf(r, today) {
    today = today || todayISO();
    if (r.verification === "Needs Verification") return "Needs Verification";
    if (r.deadlineISO && r.deadlineISO < today) return "Closed";
    if (!r.deadlineISO || !r.openingISO) return "Cycle Unconfirmed";
    if (r.openingISO > today) return "Officially Upcoming";
    return "Open";
  }

  function indianMatch(r, value) {
    var map = { yes: "Yes", conditional: "Conditional", unconfirmed: "Not confirmed" };
    return r.indian === map[value];
  }

  function searchable(r) {
    return [r.name, r.provider, r.country, r.studyLevel, r.courses, r.funding, r.categories]
      .join(" ").toLowerCase();
  }

  // params: { q, level, country, subject, funding, status, deadline, indian, category }
  function filter(list, p, today) {
    today = today || todayISO();
    var q = (p.q || "").trim().toLowerCase();
    return list.filter(function (r) {
      if (q && searchable(r).indexOf(q) === -1) return false;
      if (p.level && r.levels.indexOf(p.level) === -1) return false;
      if (p.country && r.country !== p.country) return false;
      if (p.subject && r.subjects.indexOf(p.subject) === -1) return false;
      if (p.funding && r.types.indexOf(p.funding) === -1) return false;
      if (p.status && statusOf(r, today) !== p.status) return false;
      if (p.indian && p.indian !== "any" && !indianMatch(r, p.indian)) return false;
      if (p.category === "indian" && r.country !== "India") return false;
      if (p.category === "international" && r.country === "India") return false;
      if (p.deadline && p.deadline !== "any") {
        if (p.deadline === "none") { if (r.deadlineISO) return false; }
        else if (!r.deadlineISO) return false;
        else {
          var days = daysUntil(r.deadlineISO, today);
          if (p.deadline === "30" && (days < 0 || days > 30)) return false;
          if (p.deadline === "90" && (days < 0 || days > 90)) return false;
          if (p.deadline === "later" && days <= 90) return false;
        }
      }
      return true;
    });
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }

  function statusBadge(status) {
    var b = el("span", "status-badge " + STATUS_CLASS[status], status);
    b.title = STATUS_HELP[status];
    return b;
  }

  function deadlineText(r) {
    return fmtDate(r.deadlineISO) || "Not confirmed";
  }

  function factRow(dl, label, value) {
    var wrap = el("div");
    wrap.appendChild(el("dt", null, label));
    wrap.appendChild(el("dd", null, value));
    dl.appendChild(wrap);
  }

  function renderCard(r, today) {
    var status = statusOf(r, today);
    var card = el("article", "card");
    card.appendChild(statusBadge(status));

    var h = el("h3");
    var link = el("a", null, r.name);
    link.href = "scholarship.html?id=" + encodeURIComponent(r.id);
    h.appendChild(link);
    card.appendChild(h);

    card.appendChild(el("p", "provider", r.provider || ""));

    var dl = el("dl");
    factRow(dl, "Country", r.country);
    factRow(dl, "Eligible education levels", r.levels.map(function (k) { return LEVEL_LABEL[k]; }).join(", "));
    factRow(dl, "Funding summary", r.funding || "Not confirmed");
    factRow(dl, "Deadline", deadlineText(r));
    factRow(dl, "Eligible for Indian citizens", r.indian);
    card.appendChild(dl);

    var actions = el("div", "card-actions");
    var slot = el("div", "save-slot");
    slot.setAttribute("data-save-id", r.id);
    var signInFallback = el("a", "btn btn-secondary btn-small", "Sign in to save");
    signInFallback.href = "account.html?next=" + encodeURIComponent("scholarship.html?id=" + r.id);
    slot.appendChild(signInFallback);
    actions.appendChild(slot);
    var view = el("a", "btn btn-primary btn-small", "View details");
    view.href = "scholarship.html?id=" + encodeURIComponent(r.id);
    actions.appendChild(view);
    card.appendChild(actions);

    return card;
  }

  function fillSelect(select, options, selected) {
    options.forEach(function (o) {
      var opt = el("option", null, o[1]);
      opt.value = o[0];
      if (o[0] === selected) opt.selected = true;
      select.appendChild(opt);
    });
  }

  function countries() {
    var set = {};
    records.forEach(function (r) { set[r.country] = true; });
    return Object.keys(set).sort();
  }

  window.SU = {
    records: records,
    LEVELS: LEVELS,
    SUBJECTS: SUBJECTS,
    FUNDING: FUNDING,
    STATUSES: STATUSES,
    DEADLINES: DEADLINES,
    INDIAN: INDIAN,
    CATEGORIES: CATEGORIES,
    TYPE_LABELS: TYPE_LABELS,
    STATUS_HELP: STATUS_HELP,
    LEVEL_LABEL: LEVEL_LABEL,
    todayISO: todayISO,
    fmtDate: fmtDate,
    statusOf: statusOf,
    filter: filter,
    renderCard: renderCard,
    statusBadge: statusBadge,
    fillSelect: fillSelect,
    countries: countries,
    el: el
  };
})();
