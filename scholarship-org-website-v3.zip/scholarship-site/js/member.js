/* Member features: save buttons, reminders on the detail page, sign-in page, and the dashboard.
   Everything here needs Supabase to be configured. Without it, the site shows a clear message. */
(function () {
  "use strict";
  var SU = window.SU, SUPA = window.SUPA, LOGIC = window.SULOGIC;
  if (!SU || !SUPA || !LOGIC) return;
  var el = SU.el;
  var OFFSETS = LOGIC.OFFSETS, OFFSET_LABEL = LOGIC.OFFSET_LABEL, APP_STATUSES = LOGIC.APP_STATUSES;

  function recordById(id) {
    return SU.records.filter(function (r) { return r.id === id; })[0] || null;
  }

  function errText(e) {
    return (e && e.message) || "Something went wrong. Please try again.";
  }

  function toast(text, isError) {
    var t = el("div", "toast" + (isError ? " toast-error" : ""), text);
    t.setAttribute("role", isError ? "alert" : "status");
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 4500);
  }

  function connectNote() {
    var box = el("div", "notice-box");
    box.appendChild(el("p", null, "Accounts are not connected yet. The site owner needs to complete the setup in SETUP-ACCOUNTS.md before saving, reminders and the application tracker work."));
    return box;
  }

  function todayISO() { return SU.todayISO(); }

  // ----- Save buttons on cards and detail pages -----
  var savedCache = null;

  async function savedIds() {
    if (!savedCache) {
      savedCache = {};
      (await SUPA.listWishlist()).forEach(function (x) { savedCache[x.scholarship_id] = true; });
    }
    return savedCache;
  }

  function renderSaveButton(slot, id, isSaved) {
    slot.innerHTML = "";
    var btn = el("button", "btn btn-secondary btn-small", isSaved ? "Remove from saved" : "Save scholarship");
    btn.type = "button";
    btn.setAttribute("aria-pressed", isSaved ? "true" : "false");
    btn.addEventListener("click", async function () {
      btn.disabled = true;
      try {
        if (isSaved) {
          await SUPA.removeWishlist(id);
          delete savedCache[id];
          toast("Removed from your saved scholarships.");
        } else {
          await SUPA.addWishlist(id);
          savedCache[id] = true;
          toast("Saved to your wishlist.");
        }
        renderSaveButton(slot, id, !isSaved);
      } catch (err) {
        toast(errText(err), true);
        btn.disabled = false;
      }
    });
    slot.appendChild(btn);
  }

  async function attachSaveControls() {
    var slots = document.querySelectorAll(".save-slot[data-save-id]");
    if (!slots.length) return;
    if (!SUPA.configured()) {
      slots.forEach(function (s) {
        var a = s.querySelector("a");
        if (a) {
          a.textContent = "Accounts not connected yet";
          a.removeAttribute("href");
          a.setAttribute("aria-disabled", "true");
          a.classList.add("is-disabled");
        }
      });
      return;
    }
    var user = await SUPA.currentUser();
    if (!user) return;
    var saved = await savedIds();
    slots.forEach(function (s) {
      var id = s.getAttribute("data-save-id");
      renderSaveButton(s, id, !!saved[id]);
    });
  }

  async function updateHeaderLink() {
    if (!SUPA.configured()) return;
    var user = await SUPA.currentUser();
    if (!user) return;
    document.querySelectorAll('.site-nav a[href="account.html"]').forEach(function (a) {
      a.textContent = "My Profile";
      a.setAttribute("href", "dashboard.html");
    });
  }

  // ----- Reminder form (shared by detail page and dashboard) -----
  function reminderForm(rec, currentOffsets, onSaved) {
    var wrap = el("div", "reminder-box");
    var legend = el("p", "fine-print", "Choose when to be reminded. Dates use the official deadline shown on this site.");
    wrap.appendChild(legend);

    var fieldset = el("fieldset", "checkbox-row");
    var legendEl = el("legend", null, "Reminders");
    fieldset.appendChild(legendEl);

    var today = todayISO();
    var inputs = [];
    OFFSETS.forEach(function (o) {
      var date = LOGIC.reminderDate(rec.deadlineISO, o);
      var passed = date < today;
      var label = el("label", "check-item");
      var input = el("input");
      input.type = "checkbox";
      input.name = "offset";
      input.value = String(o);
      input.checked = !passed && currentOffsets.indexOf(o) !== -1;
      input.disabled = passed;
      label.appendChild(input);
      label.appendChild(document.createTextNode(" " + OFFSET_LABEL[o] + " (" + SU.fmtDate(date) + ")" + (passed ? " · date has passed" : "")));
      fieldset.appendChild(label);
      inputs.push(input);
    });
    wrap.appendChild(fieldset);

    var save = el("button", "btn btn-primary btn-small", "Save reminders");
    save.type = "button";
    save.addEventListener("click", async function () {
      var chosen = inputs.filter(function (i) { return i.checked; }).map(function (i) { return Number(i.value); });
      save.disabled = true;
      try {
        await SUPA.setReminders(rec.id, rec.deadlineISO, chosen);
        toast(chosen.length ? "Reminders saved." : "All reminders for this scholarship were removed.");
        if (onSaved) onSaved();
      } catch (err) {
        toast(errText(err), true);
      } finally {
        save.disabled = false;
      }
    });
    wrap.appendChild(save);
    return wrap;
  }

  // ----- Detail page panel -----
  async function initDetailPanels() {
    var panel = document.getElementById("member-panels");
    if (!panel) return;
    var id = new URLSearchParams(window.location.search).get("id") || "";
    var rec = recordById(id);
    if (!rec) return;
    panel.innerHTML = "";

    var box = el("section", "facts-block");
    box.appendChild(el("h2", null, "Deadline reminders"));
    panel.appendChild(box);

    if (!SUPA.configured()) { box.appendChild(connectNote()); return; }

    var user = await SUPA.currentUser();
    if (!user) {
      box.appendChild(el("p", null, "Sign in to save this scholarship and set deadline reminders."));
      var a = el("a", "btn btn-secondary btn-small", "Sign in");
      a.href = "account.html?next=" + encodeURIComponent("scholarship.html?id=" + id);
      box.appendChild(a);
      return;
    }

    var saved = await savedIds();
    if (!saved[id]) {
      box.appendChild(el("p", null, "Save this scholarship first, then you can set deadline reminders for it."));
      return;
    }
    if (!rec.deadlineISO) {
      box.appendChild(el("p", null, "This scholarship has no confirmed deadline, so a reminder date cannot be set. We will not guess a date."));
      return;
    }

    var existing = await SUPA.listReminders();
    var current = existing.filter(function (x) { return x.scholarship_id === id; })
      .map(function (x) { return x.offset_days; });
    box.appendChild(reminderForm(rec, current, function () { initDetailPanels(); }));
    box.appendChild(el("p", "fine-print", "Reminder emails are planned for about 9:00 am India time on the reminder day. The closing time and time zone are on the official page, so check them there."));
    box.appendChild(el("p", "fine-print", "Reminders are saved now. Emails are only sent once the email setup in SETUP-ACCOUNTS.md is complete."));
    var manage = el("a", null, "Manage all reminders on your dashboard");
    manage.href = "dashboard.html";
    box.appendChild(el("p", null)).appendChild(manage);
  }

  // ----- Sign-in page -----
  function safeNext() {
    var n = new URLSearchParams(window.location.search).get("next") || "";
    return /^[a-z0-9_\-]+\.html(\?[a-z0-9_=&%.\-]*)?$/i.test(n) ? n : "";
  }

  async function initAccount() {
    var root = document.getElementById("account-root");
    if (!root) return;
    var status = document.getElementById("account-status");
    var signinForm = document.getElementById("signin-form");
    var signupForm = document.getElementById("signup-form");

    function show(text, isError) {
      status.textContent = text;
      status.className = isError ? "alert" : "status-note";
      status.setAttribute("role", isError ? "alert" : "status");
    }

    if (!SUPA.configured()) {
      root.insertBefore(connectNote(), root.firstChild);
      [signinForm, signupForm].forEach(function (f) {
        Array.prototype.forEach.call(f.elements, function (x) { x.disabled = true; });
      });
      return;
    }

    var existing = await SUPA.currentUser();
    if (existing) { window.location.replace(safeNext() || "dashboard.html"); return; }

    signinForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      var email = signinForm.elements.email.value.trim();
      var password = signinForm.elements.password.value;
      try {
        await SUPA.signIn(email, password);
        window.location.replace(safeNext() || "dashboard.html");
      } catch (err) {
        show(errText(err), true);
      }
    });

    signupForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      var name = signupForm.elements.full_name.value.trim();
      var email = signupForm.elements.email.value.trim();
      var password = signupForm.elements.password.value;
      if (password.length < 8) { show("Please use a password of at least 8 characters.", true); return; }
      try {
        var data = await SUPA.signUp(email, password, name);
        if (data.session) {
          window.location.replace(safeNext() || "dashboard.html");
        } else {
          show("Account created. Check your email to confirm it, then sign in.");
        }
      } catch (err) {
        show(errText(err), true);
      }
    });
  }

  // ----- Dashboard -----
  var data = null;

  async function loadAll() {
    var results = await Promise.all([
      SUPA.getProfile(), SUPA.listWishlist(), SUPA.listReminders(), SUPA.listApplications()
    ]);
    var wish = results[1];
    var saved = wish.map(function (w) { return recordById(w.scholarship_id); }).filter(Boolean);
    var apps = {};
    results[3].forEach(function (a) { apps[a.scholarship_id] = a; });
    savedCache = {};
    wish.forEach(function (w) { savedCache[w.scholarship_id] = true; });
    return { profile: results[0] || {}, saved: saved, reminders: results[2], apps: apps };
  }

  function section(id) {
    var s = document.getElementById(id);
    s.innerHTML = "";
    return s;
  }

  function field(id, labelText, control, hint) {
    var wrap = el("div", "field");
    var label = el("label", null, labelText);
    label.setAttribute("for", id);
    control.id = id;
    wrap.appendChild(label);
    wrap.appendChild(control);
    if (hint) wrap.appendChild(el("span", "fine-print", hint));
    return wrap;
  }

  function selectControl(name, options, value) {
    var s = el("select");
    s.name = name;
    SU.fillSelect(s, options, value);
    return s;
  }

  function textControl(name, value, placeholder) {
    var i = el("input");
    i.type = "text";
    i.name = name;
    i.value = value || "";
    if (placeholder) i.placeholder = placeholder;
    return i;
  }

  var PREFS = [
    ["full", "Full scholarship"], ["partial", "Partial scholarship"],
    ["tuition", "Tuition-fee assistance"], ["living", "Living-cost assistance"],
    ["merit", "Merit-based"], ["need", "Need-based"]
  ];

  function renderProfile() {
    var box = section("sec-profile");
    var p = data.profile;
    var form = el("form", "form-grid");
    form.appendChild(field("p-level", "Education level", selectControl("education_level",
      [["", "Not set"]].concat(SU.LEVELS), p.education_level || "")));
    form.appendChild(field("p-class", "Current class or year", textControl("current_class", p.current_class, "e.g. Class 12, 2026–27")));
    form.appendChild(field("p-degree", "Intended degree", textControl("intended_degree", p.intended_degree, "e.g. BSc Computer Science")));
    form.appendChild(field("p-subject", "Subject area", selectControl("subject",
      [["", "Not set"]].concat(SU.SUBJECTS.map(function (s) { return [s, s]; })), p.subject || "")));
    form.appendChild(field("p-home", "Home country", textControl("home_country", p.home_country || "India")));
    form.appendChild(field("p-state", "Home state or region", textControl("home_state", p.home_state, "Optional")));
    form.appendChild(field("p-dest", "Preferred study destination", selectControl("study_destination",
      [["", "Not set"], ["Any", "Any destination"]].concat(SU.countries().map(function (c) { return [c, c]; })),
      p.study_destination || "")));
    var year = el("input");
    year.type = "number";
    year.name = "intended_admission_year";
    year.min = "2026";
    year.max = "2035";
    year.value = p.intended_admission_year || "";
    form.appendChild(field("p-year", "Intended admission year", year, "Optional"));

    var fs = el("fieldset", "checkbox-row");
    fs.appendChild(el("legend", null, "Funding preferences (optional)"));
    var chosen = p.funding_preferences || [];
    PREFS.forEach(function (pref) {
      var lab = el("label", "check-item");
      var cb = el("input");
      cb.type = "checkbox";
      cb.name = "funding_preferences";
      cb.value = pref[0];
      cb.checked = chosen.indexOf(pref[0]) !== -1;
      lab.appendChild(cb);
      lab.appendChild(document.createTextNode(" " + pref[1]));
      fs.appendChild(lab);
    });
    form.appendChild(fs);

    var status = el("p", "status-note");
    status.setAttribute("role", "status");
    form.appendChild(status);

    var btn = el("button", "btn btn-primary", "Save profile");
    btn.type = "submit";
    form.appendChild(btn);

    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      var fd = new FormData(form);
      var yearVal = fd.get("intended_admission_year");
      var y = yearVal ? parseInt(yearVal, 10) : null;
      if (y !== null && (isNaN(y) || y < 2026 || y > 2035)) {
        status.textContent = "Please enter a year between 2026 and 2035, or leave it empty.";
        status.className = "alert";
        return;
      }
      var values = {
        education_level: fd.get("education_level") || null,
        current_class: (fd.get("current_class") || "").trim() || null,
        intended_degree: (fd.get("intended_degree") || "").trim() || null,
        subject: fd.get("subject") || null,
        home_country: (fd.get("home_country") || "").trim() || null,
        home_state: (fd.get("home_state") || "").trim() || null,
        study_destination: fd.get("study_destination") || null,
        intended_admission_year: y,
        funding_preferences: fd.getAll("funding_preferences")
      };
      btn.disabled = true;
      try {
        await SUPA.saveProfile(values);
        data.profile = values;
        status.textContent = "Profile saved.";
        status.className = "status-note";
        renderRecommendations();
      } catch (err) {
        status.textContent = errText(err);
        status.className = "alert";
      } finally {
        btn.disabled = false;
      }
    });

    box.appendChild(form);
  }

  function renderRecommendations() {
    var box = section("sec-recs");
    box.appendChild(el("div", "notice-box", "These recommendations are preliminary. They are based on the eligibility information we have, not a decision about you. Verify your eligibility on the official page before applying."));
    var list = LOGIC_RECOMMEND();
    if (!list.length) {
      box.appendChild(el("div", "empty-state", "No recommendations match your profile yet. Fill in your profile, or widen your choices, to see more."));
      return;
    }
    var grid = el("div", "card-grid");
    list.slice(0, 8).forEach(function (item) {
      var r = item.record;
      var card = el("article", "card");
      card.appendChild(SU.statusBadge(item.status));
      var h = el("h3");
      var a = el("a", null, r.name);
      a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      h.appendChild(a);
      card.appendChild(h);
      card.appendChild(el("p", "provider", r.provider || ""));
      card.appendChild(el("p", "fine-print", item.reasons.length
        ? "Matches your: " + item.reasons.join(", ")
        : "No profile details matched yet."));
      if (item.note) card.appendChild(el("p", "fine-print", item.note));
      card.appendChild(el("p", "fine-print", "Deadline: " + (SU.fmtDate(r.deadlineISO) || "Not confirmed")));
      if (savedCache && savedCache[r.id]) card.appendChild(el("p", "fine-print", "Already in your saved list."));
      grid.appendChild(card);
    });
    box.appendChild(grid);
  }

  function LOGIC_RECOMMEND() {
    return LOGIC.recommend(data.profile, SU.records, todayISO());
  }

  function renderWishlist() {
    var box = section("sec-wishlist");
    if (!data.saved.length) {
      box.appendChild(el("div", "empty-state", "You have not saved any scholarships yet. Use Save scholarship on a scholarship card or its details page."));
      return;
    }
    var grid = el("div", "card-grid");
    data.saved.forEach(function (r) {
      var card = el("article", "card");
      card.appendChild(SU.statusBadge(SU.statusOf(r, todayISO())));
      var h = el("h3");
      var a = el("a", null, r.name);
      a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      h.appendChild(a);
      card.appendChild(h);
      card.appendChild(el("p", "provider", r.provider || ""));
      card.appendChild(el("p", "fine-print", "Deadline: " + (SU.fmtDate(r.deadlineISO) || "Not confirmed")));
      var actions = el("div", "card-actions");
      var view = el("a", "btn btn-primary btn-small", "Open details");
      view.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      actions.appendChild(view);
      if (r.officialLink && /^https?:\/\//.test(r.officialLink)) {
        var off = el("a", "btn btn-secondary btn-small", "Official page");
        off.href = r.officialLink; off.target = "_blank"; off.rel = "noopener noreferrer";
        actions.appendChild(off);
      }
      var rm = el("button", "btn btn-secondary btn-small", "Remove");
      rm.type = "button";
      rm.addEventListener("click", async function () {
        if (!window.confirm("Remove " + r.name + " from your saved list? Its reminders will be removed too.")) return;
        try {
          await SUPA.removeWishlist(r.id);
          toast("Removed from your saved scholarships.");
          await refresh();
        } catch (err) { toast(errText(err), true); }
      });
      actions.appendChild(rm);
      card.appendChild(actions);
      grid.appendChild(card);
    });
    box.appendChild(grid);
  }

  function renderDeadlines() {
    var box = section("sec-deadlines");
    var today = todayISO();
    var list = data.saved
      .filter(function (r) { return r.deadlineISO && r.deadlineISO >= today; })
      .sort(function (a, b) { return a.deadlineISO < b.deadlineISO ? -1 : 1; });
    if (!list.length) {
      box.appendChild(el("div", "empty-state", "No upcoming confirmed deadlines for your saved scholarships."));
      return;
    }
    var ul = el("ul", "list-clean");
    list.forEach(function (r) {
      var li = el("li");
      var a = el("a", null, r.name);
      a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      li.appendChild(a);
      var days = Math.round((new Date(r.deadlineISO + "T00:00:00") - new Date(today + "T00:00:00")) / 86400000);
      li.appendChild(el("span", "meta", SU.fmtDate(r.deadlineISO) + (days === 0 ? " · closes today" : " · " + days + " days left")));
      ul.appendChild(li);
    });
    box.appendChild(ul);
  }

  function renderReminders() {
    var box = section("sec-reminders");
    if (!data.saved.length) {
      box.appendChild(el("div", "empty-state", "Save a scholarship first. You can then set deadline reminders from its details page or here."));
      return;
    }
    data.saved.forEach(function (r) {
      var rows = data.reminders.filter(function (x) { return x.scholarship_id === r.id; });
      var card = el("article", "card");
      var h = el("h3", null, r.name);
      card.appendChild(h);

      if (!r.deadlineISO) {
        card.appendChild(el("p", "fine-print", "No confirmed deadline, so reminders cannot be set."));
        box.appendChild(card);
        return;
      }

      var snapshot = rows.length ? rows[0].deadline_snapshot : null;
      if (snapshot && LOGIC.deadlineChanged(snapshot, r.deadlineISO)) {
        var warn = el("div", "alert", "The official deadline changed from " + SU.fmtDate(snapshot) + " to " + SU.fmtDate(r.deadlineISO) + ". Review these reminders, then save to confirm the new dates.");
        card.appendChild(warn);
      }

      var enabledAll = rows.length > 0 && rows.every(function (x) { return x.enabled; });
      if (rows.length) {
        var toggle = el("label", "check-item");
        var cb = el("input");
        cb.type = "checkbox";
        cb.checked = enabledAll;
        cb.addEventListener("change", async function () {
          try {
            await SUPA.setReminderEnabled(r.id, cb.checked);
            toast(cb.checked ? "Reminders turned on." : "Reminders turned off.");
            await refresh();
          } catch (err) { toast(errText(err), true); cb.checked = !cb.checked; }
        });
        toggle.appendChild(cb);
        toggle.appendChild(document.createTextNode(" Reminders on"));
        card.appendChild(toggle);
      }

      card.appendChild(reminderForm(r, rows.map(function (x) { return x.offset_days; }), refresh));

      if (rows.length) {
        var del = el("button", "btn btn-secondary btn-small", "Delete all reminders for this scholarship");
        del.type = "button";
        del.addEventListener("click", async function () {
          if (!window.confirm("Delete all reminders for " + r.name + "?")) return;
          try {
            await SUPA.deleteReminders(r.id);
            toast("Reminders deleted.");
            await refresh();
          } catch (err) { toast(errText(err), true); }
        });
        card.appendChild(del);
      }
      box.appendChild(card);
    });
  }

  function renderTracker() {
    var box = section("sec-tracker");
    box.appendChild(el("p", "fine-print", "Only you can see these notes and checklists. Scholarship.org does not submit applications for you. Apply through the official application link."));
    if (!data.saved.length) {
      box.appendChild(el("div", "empty-state", "Save a scholarship to start tracking it here."));
      return;
    }
    data.saved.forEach(function (r) {
      var app = data.apps[r.id] || { status: "Interested", notes: "", checklist: [] };
      var checklist = (app.checklist || []).map(function (c) { return { label: c.label, done: !!c.done }; });
      var card = el("article", "card");
      var h = el("h3");
      var a = el("a", null, r.name);
      a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      h.appendChild(a);
      card.appendChild(h);

      var st = el("select");
      st.name = "status";
      SU.fillSelect(st, APP_STATUSES.map(function (s) { return [s, s]; }), app.status || "Interested");
      card.appendChild(field("st-" + r.id, "Status", st));

      var notes = el("textarea");
      notes.rows = 3;
      notes.value = app.notes || "";
      card.appendChild(field("nt-" + r.id, "Private notes", notes));

      var listEl = el("ul", "checklist");
      card.appendChild(el("p", "fine-print", "Checklist of required documents"));
      card.appendChild(listEl);

      function drawChecklist() {
        listEl.innerHTML = "";
        checklist.forEach(function (item, idx) {
          var li = el("li");
          var lab = el("label", "check-item");
          var cb = el("input");
          cb.type = "checkbox";
          cb.checked = item.done;
          cb.addEventListener("change", function () { item.done = cb.checked; });
          lab.appendChild(cb);
          lab.appendChild(document.createTextNode(" " + item.label));
          li.appendChild(lab);
          var rm = el("button", "btn btn-secondary btn-small", "Remove");
          rm.type = "button";
          rm.addEventListener("click", function () { checklist.splice(idx, 1); drawChecklist(); });
          li.appendChild(rm);
          listEl.appendChild(li);
        });
      }
      drawChecklist();

      var addRow = el("div", "add-row");
      var newItem = el("input");
      newItem.type = "text";
      newItem.placeholder = "e.g. Class 12 marksheet";
      newItem.setAttribute("aria-label", "New checklist item");
      var addBtn = el("button", "btn btn-secondary btn-small", "Add item");
      addBtn.type = "button";
      addBtn.addEventListener("click", function () {
        var v = newItem.value.trim();
        if (!v) return;
        checklist.push({ label: v, done: false });
        newItem.value = "";
        drawChecklist();
      });
      addRow.appendChild(newItem);
      addRow.appendChild(addBtn);
      card.appendChild(addRow);

      var save = el("button", "btn btn-primary btn-small", "Save tracker");
      save.type = "button";
      save.addEventListener("click", async function () {
        save.disabled = true;
        try {
          await SUPA.saveApplication(r.id, {
            status: st.value, notes: notes.value, checklist: checklist
          });
          data.apps[r.id] = { scholarship_id: r.id, status: st.value, notes: notes.value, checklist: checklist };
          toast("Tracker saved.");
        } catch (err) { toast(errText(err), true); }
        finally { save.disabled = false; }
      });
      card.appendChild(save);
      box.appendChild(card);
    });
  }

  async function refresh() {
    data = await loadAll();
    renderWishlist();
    renderRecommendations();
    renderDeadlines();
    renderReminders();
    renderTracker();
  }

  async function initDashboard() {
    var root = document.getElementById("dash-root");
    if (!root) return;

    if (!SUPA.configured()) {
      root.insertBefore(connectNote(), root.firstChild);
      return;
    }

    var user = await SUPA.currentUser();
    if (!user) {
      var msg = el("div", "notice-box");
      msg.appendChild(el("p", null, "You are not signed in."));
      var a = el("a", "btn btn-primary", "Sign in");
      a.href = "account.html?next=dashboard.html";
      msg.appendChild(a);
      root.insertBefore(msg, root.firstChild);
      return;
    }

    var who = document.getElementById("dash-user");
    if (who) who.textContent = "Signed in as " + user.email + ".";
    var out = document.getElementById("signout-btn");
    if (out) out.addEventListener("click", async function () {
      try { await SUPA.signOut(); } catch (e) { /* ignore and leave */ }
      window.location.replace("index.html");
    });

    data = await loadAll();
    renderProfile();
    renderRecommendations();
    renderWishlist();
    renderDeadlines();
    renderReminders();
    renderTracker();
  }

  // Run in order of the page.
  attachSaveControls();
  updateHeaderLink();
  initDetailPanels();
  initAccount();
  initDashboard();
})();
