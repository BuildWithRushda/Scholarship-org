/* Homepage: upcoming verified deadlines and recently checked entries. */
(function () {
  "use strict";
  var SU = window.SU;
  if (!SU) return;

  var today = SU.todayISO();

  var upcomingRoot = document.getElementById("upcoming-list");
  if (upcomingRoot) {
    upcomingRoot.innerHTML = "";
    var upcoming = SU.records
      .filter(function (r) { return r.deadlineISO && r.deadlineISO >= today && SU.statusOf(r, today) === "Open"; })
      .sort(function (a, b) { return a.deadlineISO < b.deadlineISO ? -1 : 1; })
      .slice(0, 5);
    if (!upcoming.length) {
      upcomingRoot.appendChild(SU.el("li", "empty-state", "No confirmed open deadlines right now. Check back as cycles are verified."));
    } else {
      upcoming.forEach(function (r) {
        var li = SU.el("li");
        var a = SU.el("a", null, r.name);
        a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
        li.appendChild(a);
        li.appendChild(SU.el("span", "meta", "Deadline: " + SU.fmtDate(r.deadlineISO)));
        upcomingRoot.appendChild(li);
      });
    }
  }

  var recentRoot = document.getElementById("recent-list");
  if (recentRoot) {
    recentRoot.innerHTML = "";
    var recent = SU.records
      .filter(function (r) { return r.lastVerified; })
      .sort(function (a, b) { return a.lastVerified < b.lastVerified ? 1 : -1; })
      .slice(0, 3);
    recent.forEach(function (r) {
      var li = SU.el("li");
      var a = SU.el("a", null, r.name);
      a.href = "scholarship.html?id=" + encodeURIComponent(r.id);
      li.appendChild(a);
      li.appendChild(SU.el("span", "meta", "Last checked: " + SU.fmtDate(r.lastVerified) + " · " + SU.statusOf(r, today)));
      recentRoot.appendChild(li);
    });
  }
})();
