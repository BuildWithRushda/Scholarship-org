/* Supabase client and data access. Every call is limited by Row Level Security in the database,
   so a student can only read or change their own rows. No secret keys are used here. */
(function () {
  "use strict";

  var cfg = window.SITE_CONFIG || {};
  var client = null;

  function configured() {
    return !!(cfg.supabaseUrl && cfg.supabaseAnonKey);
  }

  function getClient() {
    if (client) return client;
    if (!configured() || !window.supabase || !window.supabase.createClient) return null;
    client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
    });
    return client;
  }

  function need() {
    var c = getClient();
    if (!c) throw new Error("Accounts are not connected yet.");
    return c;
  }

  function must(res) {
    if (res.error) throw new Error(res.error.message || "Something went wrong. Please try again.");
    return res.data;
  }

  async function currentUser() {
    var c = getClient();
    if (!c) return null;
    var s = must(await c.auth.getSession());
    return s && s.session ? s.session.user : null;
  }

  async function uid() {
    var u = await currentUser();
    if (!u) throw new Error("Please sign in first.");
    return u.id;
  }

  // ----- Auth -----
  async function signUp(email, password, fullName) {
    return must(await need().auth.signUp({
      email: email,
      password: password,
      options: { data: { full_name: fullName || "" } }
    }));
  }

  async function signIn(email, password) {
    return must(await need().auth.signInWithPassword({ email: email, password: password }));
  }

  async function signOut() {
    return must(await need().auth.signOut());
  }

  // ----- Profile (every field optional) -----
  async function getProfile() {
    var id = await uid();
    return must(await need().from("profiles").select("*").eq("id", id).maybeSingle());
  }

  async function saveProfile(fields) {
    var id = await uid();
    var row = Object.assign({}, fields, { id: id, updated_at: new Date().toISOString() });
    return must(await need().from("profiles").upsert(row));
  }

  // ----- Wishlist (one row per student and scholarship; the primary key prevents duplicates) -----
  async function listWishlist() {
    var id = await uid();
    return must(await need().from("wishlist").select("scholarship_id, created_at")
      .eq("user_id", id).order("created_at", { ascending: true }));
  }

  async function addWishlist(scholarshipId) {
    var id = await uid();
    return must(await need().from("wishlist").upsert(
      { user_id: id, scholarship_id: scholarshipId },
      { onConflict: "user_id,scholarship_id", ignoreDuplicates: true }
    ));
  }

  // Removing a saved scholarship also removes its reminders. Application notes are kept.
  async function removeWishlist(scholarshipId) {
    var c = need();
    var id = await uid();
    must(await c.from("reminders").delete().eq("user_id", id).eq("scholarship_id", scholarshipId));
    return must(await c.from("wishlist").delete().eq("user_id", id).eq("scholarship_id", scholarshipId));
  }

  // ----- Reminders (one row per student, scholarship and offset) -----
  async function listReminders() {
    var id = await uid();
    return must(await need().from("reminders").select("*").eq("user_id", id).order("created_at", { ascending: true }));
  }

  // Makes the stored reminders for one scholarship match the chosen offsets.
  // Also records the deadline the reminders are based on, so later changes can be flagged.
  async function setReminders(scholarshipId, deadlineISO, offsets) {
    var c = need();
    var id = await uid();
    var existing = must(await c.from("reminders").select("offset_days")
      .eq("user_id", id).eq("scholarship_id", scholarshipId));
    var have = existing.map(function (x) { return x.offset_days; });
    var toRemove = have.filter(function (o) { return offsets.indexOf(o) === -1; });
    if (toRemove.length) {
      must(await c.from("reminders").delete().eq("user_id", id)
        .eq("scholarship_id", scholarshipId).in("offset_days", toRemove));
    }
    if (offsets.length) {
      var rows = offsets.map(function (o) {
        return { user_id: id, scholarship_id: scholarshipId, offset_days: o,
                 deadline_snapshot: deadlineISO, enabled: true };
      });
      must(await c.from("reminders").upsert(rows, { onConflict: "user_id,scholarship_id,offset_days" }));
    }
    return true;
  }

  async function setReminderEnabled(scholarshipId, enabled) {
    var id = await uid();
    return must(await need().from("reminders").update({ enabled: enabled })
      .eq("user_id", id).eq("scholarship_id", scholarshipId));
  }

  async function deleteReminders(scholarshipId) {
    var id = await uid();
    return must(await need().from("reminders").delete().eq("user_id", id).eq("scholarship_id", scholarshipId));
  }

  // ----- Application tracker (private notes and checklist) -----
  async function listApplications() {
    var id = await uid();
    return must(await need().from("applications").select("*").eq("user_id", id));
  }

  async function saveApplication(scholarshipId, fields) {
    var id = await uid();
    var row = Object.assign({}, fields, {
      user_id: id, scholarship_id: scholarshipId, updated_at: new Date().toISOString()
    });
    return must(await need().from("applications").upsert(row, { onConflict: "user_id,scholarship_id" }));
  }

  window.SUPA = {
    configured: configured,
    getClient: getClient,
    currentUser: currentUser,
    signUp: signUp,
    signIn: signIn,
    signOut: signOut,
    getProfile: getProfile,
    saveProfile: saveProfile,
    listWishlist: listWishlist,
    addWishlist: addWishlist,
    removeWishlist: removeWishlist,
    listReminders: listReminders,
    setReminders: setReminders,
    setReminderEnabled: setReminderEnabled,
    deleteReminders: deleteReminders,
    listApplications: listApplications,
    saveApplication: saveApplication
  };
})();
