/* Browse hub: counts from the central database. Zero counts show an honest empty state. */
(function () {
  "use strict";
  var SU = window.SU;
  if (!SU) return;

  var NAMED_COUNTRIES = ["United States", "United Kingdom", "Canada", "Australia", "Germany", "Japan", "South Korea", "Singapore"];

  function setCount(id, count, href) {
    var node = document.getElementById(id);
    if (!node) return;
    node.innerHTML = "";
    if (count === 0) {
      node.appendChild(SU.el("span", "muted", "No verified entries yet."));
      return;
    }
    var label = count + (count === 1 ? " entry" : " entries") + " in the database";
    if (href) {
      var a = SU.el("a", null, label + ". View them");
      a.href = href;
      node.appendChild(a);
    } else {
      node.appendChild(SU.el("span", null, label));
    }
  }

  SU.LEVELS.forEach(function (l) {
    var count = SU.records.filter(function (r) { return r.levels.indexOf(l[0]) !== -1; }).length;
    setCount("count-level-" + l[0], count, "scholarships.html?level=" + encodeURIComponent(l[0]));
  });

  var namedCount = function (name) {
    return SU.records.filter(function (r) { return r.country === name; }).length;
  };

  NAMED_COUNTRIES.forEach(function (name) {
    var id = "count-country-" + name.toLowerCase().replace(/\s+/g, "-");
    setCount(id, namedCount(name), "scholarships.html?country=" + encodeURIComponent(name));
  });

  var otherInternational = SU.records.filter(function (r) {
    return r.country !== "India" && NAMED_COUNTRIES.indexOf(r.country) === -1;
  }).length;
  setCount("count-country-other-international", otherInternational, null);
  setCount("count-country-other-european", 0, null);
  setCount("count-country-other-asian", 0, null);

  var indianCount = SU.records.filter(function (r) { return r.country === "India"; }).length;
  setCount("count-indian", indianCount, "scholarships.html?category=indian");

  var intlCount = SU.records.filter(function (r) { return r.country !== "India"; }).length;
  setCount("count-international", intlCount, "scholarships.html?category=international");
  setCount("count-study-abroad", intlCount, "scholarships.html?category=international");
})();
