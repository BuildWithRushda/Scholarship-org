/* Scholarship detail page: shows every field from the record, with official links. */
(function () {
  "use strict";
  var SU = window.SU;
  if (!SU) return;

  var root = document.getElementById("detail");
  if (!root) return;

  var id = new URLSearchParams(window.location.search).get("id") || "";
  var r = SU.records.filter(function (x) { return x.id === id; })[0];

  root.innerHTML = "";

  if (!r) {
    var alert = SU.el("div", "alert");
    alert.textContent = "This scholarship could not be found. Check the link, or browse the directory.";
    root.appendChild(alert);
    var back = SU.el("p");
    var a = SU.el("a", null, "Go to the scholarship directory");
    a.href = "scholarships.html";
    back.appendChild(a);
    root.appendChild(back);
    return;
  }

  var today = SU.todayISO();
  var status = SU.statusOf(r, today);
  document.title = r.name + " | Scholarship.org Education Initiative";
  var desc = document.querySelector('meta[name="description"]');
  if (desc) desc.setAttribute("content", (r.provider ? r.provider + ". " : "") + "Eligibility, funding, deadline and official links for " + r.name + ". Confirm details on the official page.");

  // Breadcrumb
  var crumb = SU.el("p", "breadcrumb");
  var c1 = SU.el("a", null, "Home"); c1.href = "index.html";
  var c2 = SU.el("a", null, "Scholarships"); c2.href = "scholarships.html";
  crumb.appendChild(c1); crumb.appendChild(document.createTextNode(" / "));
  crumb.appendChild(c2); crumb.appendChild(document.createTextNode(" / " + r.id));
  root.appendChild(crumb);

  var header = SU.el("header", "page-intro");
  header.appendChild(SU.statusBadge(status));
  header.appendChild(SU.el("h1", null, r.name));
  if (r.provider) header.appendChild(SU.el("p", "lead", r.provider));
  root.appendChild(header);

  // Status explanation
  var statusBox = SU.el("div", "notice-box");
  statusBox.appendChild(SU.el("p", null, "Status: " + status + ". " + SU.STATUS_HELP[status]));
  statusBox.appendChild(SU.el("p", "muted", "Verification status in the tracker: " + (r.verification || "Not recorded") + ". Last checked: " + (SU.fmtDate(r.lastVerified) || "Not recorded") + "."));
  root.appendChild(statusBox);

  // Quick facts
  var quick = SU.el("dl", "quick-facts");
  function qf(label, value) {
    var wrap = SU.el("div");
    wrap.appendChild(SU.el("dt", null, label));
    wrap.appendChild(SU.el("dd", null, value));
    quick.appendChild(wrap);
  }
  qf("Deadline", SU.fmtDate(r.deadlineISO) || "Not confirmed");
  qf("Application status", status);
  qf("Eligible for Indian citizens", r.indian);
  root.appendChild(quick);

  // Save: requires an account (not yet available)
  var saveRow = SU.el("div", "button-row");
  var slot = SU.el("div", "save-slot");
  slot.setAttribute("data-save-id", r.id);
  var fallback = SU.el("a", "btn btn-secondary", "Sign in to save this scholarship");
  fallback.href = "account.html?next=" + encodeURIComponent("scholarship.html?id=" + r.id);
  slot.appendChild(fallback);
  saveRow.appendChild(slot);
  root.appendChild(saveRow);

  var panels = SU.el("div");
  panels.id = "member-panels";
  root.appendChild(panels);

  function block(title, rows) {
    var sec = SU.el("section", "facts-block");
    sec.appendChild(SU.el("h2", null, title));
    var dl = SU.el("dl", "detail-dl");
    rows.forEach(function (row) {
      if (!row[1]) return;
      dl.appendChild(SU.el("dt", null, row[0]));
      var dd = SU.el("dd");
      if (row[2] && /^https?:\/\//.test(row[1])) {
        var link = SU.el("a", null, row[1]);
        link.href = row[1];
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        dd.appendChild(link);
      } else {
        dd.textContent = row[1];
      }
      dl.appendChild(dd);
    });
    sec.appendChild(dl);
    return sec;
  }

  var facts = SU.el("div", "facts");

  facts.appendChild(block("Eligibility", [
    ["Eligible education levels", r.levels.map(function (k) { return SU.LEVEL_LABEL[k]; }).join(", ")],
    ["Study level", r.studyLevel],
    ["Eligible nationalities", r.nationalities],
    ["Eligible student categories", r.categories],
    ["Academic requirements", r.academic],
    ["Family income requirements", r.income],
    ["Eligible courses", r.courses],
    ["Admission required before applying", r.admission],
    ["Nomination required", r.nomination],
    ["Eligible for Indian citizens", r.indian]
  ]));

  facts.appendChild(block("Funding", [
    ["Funding coverage", r.funding],
    ["Scholarship amount", r.amount],
    ["Funding types", r.types.map(function (t) { return SU.TYPE_LABELS[t]; }).join(", ")]
  ]));

  facts.appendChild(block("Dates", [
    ["Application opening", SU.fmtDate(r.openingISO) || r.openingNote || "Not confirmed"],
    ["Application deadline", SU.fmtDate(r.deadlineISO) || "Not confirmed"],
    ["Deadline details", r.deadlineNote]
  ]));

  facts.appendChild(block("Required documents", [
    ["Documents", r.documents]
  ]));

  facts.appendChild(block("Official links", [
    ["Official scholarship page", r.officialLink, true],
    ["Official application link", r.applicationLink, true]
  ]));

  facts.appendChild(block("Verification", [
    ["Verification status", r.verification],
    ["Last checked", SU.fmtDate(r.lastVerified)],
    ["Notes", r.notes]
  ]));

  root.appendChild(facts);

  var disclaimer = SU.el("div", "notice-box");
  disclaimer.appendChild(SU.el("p", null, "Confirm every detail on the official page before applying. Eligibility, amounts and deadlines can change, and Scholarship.org Education Initiative does not guarantee funding or selection."));
  root.appendChild(disclaimer);

  var back2 = SU.el("p");
  var b = SU.el("a", null, "Back to all scholarships");
  b.href = "scholarships.html";
  back2.appendChild(b);
  root.appendChild(back2);
})();
