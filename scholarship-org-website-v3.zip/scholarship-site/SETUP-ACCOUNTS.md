# Setting up accounts, saving, reminders and the application tracker

These features need a free Supabase project (accounts and saved data) and, for reminder emails, a free email service and a Git-based Netlify deploy. Until you complete these steps, the site shows "not connected yet" messages and saves nothing.

Free-tier limits and prices change. Check supabase.com/pricing, resend.com/pricing and netlify.com/pricing before you rely on them.

## Part 1: Supabase (accounts and saved data)

1. Go to supabase.com, sign up, and click **New project**. Choose a name, a database password (save it somewhere safe), and the region closest to your students.
2. Wait for the project to finish setting up.
3. Click **SQL Editor**, then **New query**. Open `supabase/schema.sql` from the project, copy everything, paste it, and click **Run**. You should see "Success".
4. Click **Project Settings** (gear icon), then **API**. Copy:
   - **Project URL** (looks like https://abcdefgh.supabase.co)
   - **anon public** key (a long string starting with `eyJ...`)
   The anon key is designed to be public. Do **not** copy the **service_role** key here.
5. Open `config.js` and paste the two values:
   ```
   supabaseUrl: "https://abcdefgh.supabase.co",
   supabaseAnonKey: "eyJ...",
   ```
6. Under **Authentication**, then **Sign In / Providers**, check that Email is enabled. Under **Authentication**, then **URL Configuration**, set the Site URL to your Netlify address (for example https://scholarshiporg.netlify.app) so confirmation links open your site.
7. Redeploy the site (see DEPLOYMENT.md). Then test: create an account, sign in, save a scholarship, refresh the page, sign in on another browser and check it is still there.

Email confirmation: by default, Supabase asks new users to confirm their email. The sign-up page tells them to check their inbox. You can leave this on.

## Part 2: Reminder emails (optional, needed only for emails)

Reminders are saved in Supabase even without this part, but **no emails are sent** until you complete it.

1. Create a free account at resend.com and create an API key.
2. Choose a sender address. Resend requires you to verify a domain before you can send to any address other than your own; check Resend's current rules for the free plan.
3. Deploy the site from a **GitHub repository connected to Netlify**. Scheduled functions do not run for drag-and-drop deploys.
4. In Netlify, open **Site configuration**, then **Environment variables**, and add these as secret values:
   - `SUPABASE_URL` : the Project URL from Part 1
   - `SUPABASE_SERVICE_ROLE_KEY` : the **service_role** key from Supabase (keep this secret; never put it in config.js or any website file)
   - `RESEND_API_KEY` : your Resend API key
   - `REMINDER_FROM_EMAIL` : your verified sender address
5. Redeploy. The job runs every day at 09:00 India time. To test, open **Functions** in Netlify and run `send-reminders` manually. Its response says how many reminders were sent and skipped.

Reminders for a deadline that has changed are skipped until the student reviews them on the dashboard. This is deliberate, so no one receives a reminder for a date that is no longer correct.

## Part 3: Testing checklist

- Create an account with a new email. Confirm the email if asked.
- Save a scholarship on a card and on its details page. Refresh: it is still saved.
- Sign out, sign in on a different browser: the same saved scholarships appear.
- Set reminders on a scholarship with a confirmed deadline. Check they appear on the dashboard.
- Edit the tracker: change status, add a note and checklist item, save, refresh.
- Sign in with a second test account: confirm it cannot see the first account's data.
