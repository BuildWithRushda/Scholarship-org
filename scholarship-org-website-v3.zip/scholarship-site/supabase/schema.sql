-- Scholarship.org Education Initiative: student accounts database.
-- Run this once in Supabase: SQL Editor > New query > paste > Run.
-- Safe to re-run: it uses "if not exists" and drops only its own policies before recreating them.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  education_level text,
  current_class text,
  intended_degree text,
  subject text,
  home_country text,
  home_state text,
  study_destination text,
  intended_admission_year int check (intended_admission_year is null or intended_admission_year between 2026 and 2035),
  funding_preferences text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.wishlist (
  user_id uuid not null references auth.users(id) on delete cascade,
  scholarship_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, scholarship_id)
);

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  scholarship_id text not null,
  offset_days int not null check (offset_days in (30, 14, 7, 3, 1, 0)),
  deadline_snapshot date not null,
  enabled boolean not null default true,
  last_sent_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, scholarship_id, offset_days)
);

create table if not exists public.applications (
  user_id uuid not null references auth.users(id) on delete cascade,
  scholarship_id text not null,
  status text not null default 'Interested'
    check (status in ('Interested', 'Preparing Documents', 'Ready to Apply', 'Applied', 'Awarded', 'Not Pursuing')),
  notes text not null default '',
  checklist jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, scholarship_id)
);

-- Turn on Row Level Security: nothing is readable or writable without a matching policy.
alter table public.profiles enable row level security;
alter table public.wishlist enable row level security;
alter table public.reminders enable row level security;
alter table public.applications enable row level security;

-- Remove access for logged-out visitors entirely.
revoke all on public.profiles from anon;
revoke all on public.wishlist from anon;
revoke all on public.reminders from anon;
revoke all on public.applications from anon;

-- Each signed-in student can only see and change rows that belong to them.
drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles
  for all to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "own wishlist" on public.wishlist;
create policy "own wishlist" on public.wishlist
  for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own reminders" on public.reminders;
create policy "own reminders" on public.reminders
  for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own applications" on public.applications;
create policy "own applications" on public.applications
  for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
