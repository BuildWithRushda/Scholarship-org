/*
  ==========================================================
  SITE SETTINGS: edit only this file for these values.
  ==========================================================

  surveyUrl       : the student survey link (keep as is).
  contactEmail    : your real contact email, once you have one.
  supabaseUrl     : from Supabase > Project Settings > API > Project URL.
  supabaseAnonKey : from Supabase > Project Settings > API > anon public key.
                    The anon key is designed to be public. NEVER put the
                    "service_role" key here; it stays in Netlify environment
                    variables only (see SETUP-ACCOUNTS.md).

  Leave the Supabase values empty until you have completed SETUP-ACCOUNTS.md.
  While empty, accounts show a "not connected yet" message and nothing is saved.
  ==========================================================
*/
window.SITE_CONFIG = {
  surveyUrl: "https://tally.so/r/8NNxBz",
  contactEmail: "",
  supabaseUrl: "",
  supabaseAnonKey: ""
};
